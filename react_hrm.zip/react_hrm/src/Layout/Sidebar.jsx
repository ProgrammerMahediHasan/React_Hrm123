import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import feather from 'feather-icons';
import "./sidebar.css";

const Sidebar = () => {
  useEffect(() => {
    feather.replace();
  }, []);

  const customArrow = (
    <svg
      width="14"
      height="14"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      style={{ flexShrink: 0 }}
    >
      <path d="M9 18l6-6-6-6" />
    </svg>
  );

  return (
    <nav id="sidebar" className="sidebar js-sidebar">
      <div className="sidebar-content js-simplebar">
        <a className="sidebar-brand" href="index.html">
          <span className="align-middle">NextPrime</span>
        </a>

        <ul className="sidebar-nav">

          <li className="sidebar-header">
            HRMS & PAYROLL
          </li>

          <li className="sidebar-item active">
            <Link className="sidebar-link" to="/">
              <i className="align-middle" data-feather="sliders" />
              <span className="align-middle">Dashboard</span>
            </Link>
          </li>



          
          {/* HR Module Dropdown */}
          <li className="sidebar-item">
            <a
              data-bs-target="#hrDropdown"
              data-bs-toggle="collapse"
              className="sidebar-link collapsed collapsible"
              href="#hrDropdown"
            >
              <i className="align-middle" data-feather="users" />
              <span className="align-middle">HR Module</span>
            </a>

            <ul
              id="hrDropdown"
              className="sidebar-dropdown list-unstyled collapse"
              data-bs-parent="#sidebar"
            >
              {[
                { name: "User", path: "/user" },
                { name: "Role", path: "/role" },
                { name: "Department", path: "/department" },
                { name: "Designation", path: "/designation" },
                { name: "Employee", path: "/employee" },
              ].map(({ name, path }, i) => (
                <li key={i} className="sidebar-item">
                  <Link
                    className="sidebar-link"
                    to={path}
                    style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
                  >
                    {customArrow}
                    <span>{name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </li>


          {/* Attendance Module Dropdown */}
          <li className="sidebar-item">
            <a
              data-bs-target="#attednDropdown"
              data-bs-toggle="collapse"
              className="sidebar-link collapsed collapsible"
              href="#attednDropdown"
            >
              <i className="align-middle" data-feather="users" />
              <span className="align-middle">Attendance Module</span>
            </a>

            <ul
              id="attednDropdown"
              className="sidebar-dropdown list-unstyled collapse"
              data-bs-parent="#sidebar"
            >
              {[
                { name: " Attendence System", path: "/attendance_log" },
                { name: " Daily Attendence", path: "/DailyAttendance" },
                { name: " Leave Configuration", path: "/LeaveConfiguration" },
                { name: " Leave Request", path: "/LeaveRequest" }
              ].map(({ name, path }, i) => (
                <li key={i} className="sidebar-item">
                  <Link
                    className="sidebar-link"
                    to={path}
                    style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
                  >
                    {customArrow}
                    <span>{name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </li>


          {/* Payroll Module Dropdown */}
          <li className="sidebar-item">
            <a
              data-bs-target="#payrollDropdown"
              data-bs-toggle="collapse"
              className="sidebar-link collapsed collapsible"
              href="#payrollDropdown"
            >
              <i className="align-middle" data-feather="users" />
              <span className="align-middle">Payroll Module</span>
            </a>

            <ul
              id="payrollDropdown"
              className="sidebar-dropdown list-unstyled collapse"
              data-bs-parent="#sidebar"
            >
              {[
                { name: " Salary Configuration", path: "/user" },
                { name: " Payslip", path: "/role" }
              ].map(({ name, path }, i) => (
                <li key={i} className="sidebar-item">
                  <Link
                    className="sidebar-link"
                    to={path}
                    style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
                  >
                    {customArrow}
                    <span>{name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </li>


          {/*  Reports & Analytics Module Dropdown */}
          <li className="sidebar-item">
            <a
              data-bs-target="#ReportsDropdown"
              data-bs-toggle="collapse"
              className="sidebar-link collapsed collapsible"
              href="#ReportsDropdown"
            >
              <i className="align-middle" data-feather="users" />
              <span className="align-middle">Reports Module</span>
            </a>

            <ul
              id="ReportsDropdown"
              className="sidebar-dropdown list-unstyled collapse"
              data-bs-parent="#sidebar"
            >
              {[
                { name: "Employee Information", path: "/employInfo" },
                { name: "Daily Attendance", path: "/dailyAttReport" },
                { name: "Monthly Attendence", path: "/monthly_attendance_report" },
                { name: "Monthly Summary", path: "/designation" },
                { name: "Employee Leave", path: "/employee" },
                { name: "Leave Summary", path: "/employee" },
                { name: "Payroll Summary", path: "/employee" },
              ].map(({ name, path }, i) => (
                <li key={i} className="sidebar-item">
                  <Link
                    className="sidebar-link"
                    to={path}
                    style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
                  >
                    {customArrow}
                    <span>{name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </li>




          {/* Other existing menu items */}
          <li className="sidebar-item">
            <a className="sidebar-link" href="pages-sign-in.html">
              <i className="align-middle" data-feather="log-in" />
              <span className="align-middle">Sign In</span>
            </a>
          </li>

          <li className="sidebar-item">
            <a className="sidebar-link" href="pages-sign-up.html">
              <i className="align-middle" data-feather="user-plus" />
              <span className="align-middle">Sign Up</span>
            </a>
          </li>

          {/* <li className="sidebar-item">
            <a className="sidebar-link" href="pages-blank.html">
              <i className="align-middle" data-feather="book" />
              <span className="align-middle">Blank</span>
            </a>
          </li>

          <li className="sidebar-header">
            Tools &amp; Components
          </li>

          <li className="sidebar-item">
            <a className="sidebar-link" href="ui-buttons.html">
              <i className="align-middle" data-feather="square" />
              <span className="align-middle">Buttons</span>
            </a>
          </li>

          <li className="sidebar-item">
            <a className="sidebar-link" href="ui-forms.html">
              <i className="align-middle" data-feather="check-square" />
              <span className="align-middle">Forms</span>
            </a>
          </li> */}

        </ul>
      </div>
    </nav>
  );
};

export default Sidebar;
