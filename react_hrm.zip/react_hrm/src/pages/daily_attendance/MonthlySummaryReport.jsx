import axios from "axios";
import React, { useEffect, useState } from "react";
import "./pagination.css";

const MonthlySummaryReport = () => {
  const [summary, setSummary] = useState([]);
  const [empId, setEmpId] = useState("");
  const [month, setMonth] = useState("");
  const [year, setYear] = useState("");

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 6;
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = summary.slice(indexOfFirstRow, indexOfLastRow);
  const totalPages = Math.ceil(summary.length / rowsPerPage);

  // Month & Year options
  const monthOptions = [
    { value: "1", label: "January" },
    { value: "2", label: "February" },
    { value: "3", label: "March" },
    { value: "4", label: "April" },
    { value: "5", label: "May" },
    { value: "6", label: "June" },
    { value: "7", label: "July" },
    { value: "8", label: "August" },
    { value: "9", label: "September" },
    { value: "10", label: "October" },
    { value: "11", label: "November" },
    { value: "12", label: "December" },
  ];
  const currentYear = new Date().getFullYear();
  const yearOptions = Array.from({ length: 10 }, (_, i) => currentYear - i);

  // Fetch API
  const getMonthlySummary = () => {
    if (!month || !year) {
      setSummary([]);
      return;
    }
    axios
      .post(
        "http://localhost:8080/PHP_Converted/admin/api/DailyAttendance/monthlysummaryreport",
        { report_month: month, report_year: year, emp_id: empId || null }
      )
      .then((res) => {
        setSummary(res.data.monthly_summary || []);
        setCurrentPage(1); // Reset pagination
      })
      .catch((err) => console.log(err));
  };

  // Clear filters
  const clearFilters = () => {
    setEmpId("");
    setMonth("");
    setYear("");
    setSummary([]);
    setCurrentPage(1);
  };

  return (
    <>
      <h2 className="text-center my-4">Monthly Attendance Summary</h2>

      {/* Filters */}
      <div className="container mb-3">
        <div className="row g-2">
          {/* Employee ID */}
          <div className="col-md-3">
            <input
              type="text"
              className="form-control"
              placeholder="Employee ID (optional)"
              value={empId}
              onChange={(e) => setEmpId(e.target.value)}
            />
          </div>

          {/* Month select */}
          <div className="col-md-3">
            <select
              className="form-control"
              value={month}
              onChange={(e) => setMonth(e.target.value)}
            >
              <option value="">Select Month</option>
              {monthOptions.map((m) => (
                <option key={m.value} value={m.value}>
                  {m.label}
                </option>
              ))}
            </select>
          </div>

          {/* Year select */}
          <div className="col-md-3">
            <select
              className="form-control"
              value={year}
              onChange={(e) => setYear(e.target.value)}
            >
              <option value="">Select Year</option>
              {yearOptions.map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </div>

          {/* Search + Clear buttons */}
          <div className="col-md-3 d-flex gap-2">
            <button className="btn btn-primary w-50" onClick={getMonthlySummary}>
              Search
            </button>
            <button className="btn btn-secondary w-50" onClick={clearFilters}>
              Clear
            </button>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="container">
        <table className="table table-bordered table-striped">
          <thead
            className="text-white"
            style={{ backgroundColor: "#0c3f7a", fontSize: "0.9rem" }}
          >
            <tr>
              <th>Emp ID</th>
              <th>Name</th>
              <th>Present</th>
              <th>Absent</th>
              <th>Leave</th>
              <th>Total Late</th>
              <th>Total OT</th>
            </tr>
          </thead>
          <tbody>
            {currentRows.map((row, i) => (
              <tr key={i}>
                <td>{row.emp_id}</td>
                <td>{row.emp_name}</td>
                <td>{row.total_attendance}</td>
                <td>{row.total_absent}</td>
                <td>{row.total_leave}</td>
                <td>{row.total_late}</td>
                <td>{row.total_overtime}</td>
              </tr>
            ))}
            {currentRows.length === 0 && (
              <tr>
                <td colSpan="7" className="text-center text-muted py-3">
                  No records found
                </td>
              </tr>
            )}
          </tbody>
        </table>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="pagination">
            <a
              className={currentPage === 1 ? "disabled" : ""}
              onClick={() =>
                currentPage > 1 && setCurrentPage(currentPage - 1)
              }
            >
              « Previous
            </a>
            {[...Array(totalPages)].map((_, index) => (
              <a
                key={index}
                className={currentPage === index + 1 ? "active" : ""}
                onClick={() => setCurrentPage(index + 1)}
              >
                {index + 1}
              </a>
            ))}
            <a
              className={currentPage === totalPages ? "disabled" : ""}
              onClick={() =>
                currentPage < totalPages &&
                setCurrentPage(currentPage + 1)
              }
            >
              Next »
            </a>
          </div>
        )}
      </div>
    </>
  );
};

export default MonthlySummaryReport;
