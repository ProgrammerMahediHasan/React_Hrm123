import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateDesig = () => {
  const [designation, setdesignation] = useState({
    name: '',
    description: ''
  });

  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setdesignation((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Submitting designation:', designation);

    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/designation/save',
      method: 'POST',
      data: designation
    })
      .then((res) => {
        console.log(res.data.designation);
        if (res) {
          navigate('/designation'); // redirect to user list after successful creation
        }
      })
      .catch((err) => console.log(err));
  };

  // Handle back button
  const handleBack = () => {
    navigate(-1); // go to previous page
  };

  return (
    <div
      style={{
        maxWidth: '500px',
        margin: '20px auto',
        padding: '20px',
        border: '1px solid #ccc',
        borderRadius: '8px'
      }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-3"
        style={{ cursor: 'pointer' }}
      >
        &larr; Back
      </button>

      <h3 className="text-center mb-4">Create Designation</h3>
      <form onSubmit={handleSubmit}>
        {/* Username */}
        <div className="mb-3">
          <label htmlFor="username" className="form-label">Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={designation.name}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter name"
            required
          />
        </div>


        <div className="mb-3">
          <label htmlFor="description" className="form-label">description</label>
          <input
            type="description"
            id="description"
            name="description"
            value={designation.description}
            onChange={handleChange}
            className="form-control"
            placeholder="Enter description"
            required
          />
        </div>


        {/* Submit Button */}
        <div className="text-center">
          <button type="submit" className="btn btn-primary">
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateDesig;
