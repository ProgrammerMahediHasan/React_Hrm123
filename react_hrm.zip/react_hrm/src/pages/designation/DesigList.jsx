import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
// import Header from '../../Layout/Header';
// import Footer from '../../Layout/Footer';

const DesigList = () => {

  const getdesignation = () => {
    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/designation/",
      method: "GET",
      data: {}
    })
      .then((res) => {
        console.log(res.data.designations);
        setdesignation(res.data.designations)
      })
      .catch((err) => {
        console.log(err);
      });
  }

  const [designation, setdesignation] = useState([]);

  useEffect (() => {getdesignation()},[]);

  // Delete function 
  const deletedesignation = (id) => {
    const Delete = window.confirm("Are you sure you want to delete this user?");
    if (!Delete) return;

    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/designation/delete/",
      method: "DELETE",
      data: { id }
    })
      .then(res => {
        console.log(res.data.designations);
        getdesignation(); // refresh table after delete
      })
      .catch(err => console.log(err));
  };


  
 // ✅ Pagination States
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 6;


  // ✅ Pagination Logic
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = designation.slice(indexOfFirstRow, indexOfLastRow);

  const totalPages = Math.ceil(designation.length / rowsPerPage);


  return (
    
<>

{/* <Header /> */}
  <h1 className="text-center my-4">Designation List</h1>

  <div className="container" style={{ paddingBottom: "80px" }}>
        {/* Create Button */}
        <div className="d-flex justify-content-between align-items-center mb-4">
          <Link to="/designation/create" className="btn btn-success">
            Add Designation
          </Link>
        </div>

  <div className="container">
    <table className="table table-bordered table-striped">
      <thead className="text-white"
                style={{ backgroundColor: "#0c3f7aea", fontSize: "0.88rem" }}>
        <tr>
          <th scope="col">Id</th>
          <th scope="col">Name</th>
          <th scope="col">Description</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        {designation.map((desig, i) => (
          <tr key={i}>
            <th scope="row">{++i}</th>
            <td>{desig.name}</td>
            <td>{desig.description}</td>
            <td>
              <Link 
  to={`/designation/edit/${desig.id}`} 
  className="btn btn-info me-2"
>
  Edit
</Link>

 {/* Delete button with icon */}
         <button
          onClick={() => deletedesignation(desig.id)}
          className="btn btn-danger"
          style={{ width: "50px", display: "flex", justifyContent: "center" }}>
          <i className="bi bi-trash"></i>
        </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>

 {/* Pagination  */}


<div className="pagination">

  <a
    className={currentPage === 1 ? "disabled" : ""}
    onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
  >
    « Previous
  </a>

  {[...Array(totalPages)].map((_, index) => (
    <a
      key={index}
      className={currentPage === index + 1 ? "active" : ""}
      onClick={() => setCurrentPage(index + 1)}
    >
      {index + 1}
    </a>
  ))}

  <a
    className={currentPage === totalPages ? "disabled" : ""}
    onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
  >
    Next »
  </a>

</div>

    </div>
  </div>
  {/* <Footer /> */}
</>


  );
};

export default DesigList;
