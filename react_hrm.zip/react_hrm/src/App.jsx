import { useState } from 'react'

import Layout from './Layout/Layout'
import CreateRole from './pages/roles/CreateRole'
import EditRole from './pages/roles/EditRole'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import RoleList from './pages/roles/RoleList'


// import EmployInfo from './pages/roles/EmployInfo'
import UserList from './pages/users/UserList'
// import CreateUser from './pages/users/CreateUser'
import DeptList from './pages/department/DeptList'
import CreateDept from './pages/department/CreateDept'
import DesigList from './pages/designation/DesigList'
import CreateDesig from './pages/designation/CreateDesig'
import EmpList from './pages/employee/EmpList'
import CreateEmp from './pages/employee/CreateEmp'
import Dashboard from './pages/dashboard/Dashboard'
import AttenLogList from './pages/attendance_log/AttenLogList'
import DailyAttendList from './pages/daily_attendance/DailyAttendList'
import LeaveConfigList from './pages/leave_configuration/LeaveConfigList'
import LeaveReqList from './pages/leave_request/LeaveReqList'
import EmployInfo from './pages/employee/EmployInfo'
import EmpSalList from './pages/employee_salary/EmpSalList'
import DailyAttendReport from './pages/daily_attendance/DailyAttendReport'
import MonthlySummaryReport from './pages/daily_attendance/MonthlySummaryReport'
// import EditUser from './pages/users/EditUser'
// import Dashboard from './pages/dashobard/Dashboard'






function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      
 <BrowserRouter>

      <Routes>
        <Route path="/" element={<Layout />} >


        <Route path="/role" element={<RoleList />} />
        <Route path="/role/edit/:roleId" element={<EditRole />} />
        <Route path="/role/create" element={<CreateRole />} />
        {/* <Route path="/employee" element={<EmployInfo />} /> */}


        <Route path="/user" element={<UserList />} />
        {/* <Route path="/user/create" element={<CreateUser />} />
        <Route path="/user/edit/:userId" element={<EditUser />} /> */}


        <Route path="/department" element={<DeptList />} />
        <Route path="/department/create" element={<CreateDept />} />


        <Route path="/designation" element={<DesigList />} />
        <Route path="/designation/create" element={<CreateDesig />} />

         <Route path="/employee" element={<EmpList />} />
         <Route path="/employInfo" element={<EmployInfo />} />
         <Route path="/employee/create" element={<CreateEmp />} />
 
         <Route path="/" element={<Dashboard/>} />
        {/* <Route path="/" element={<role />} /> */}


          <Route path="/attendance_log" element={<AttenLogList/>} />

          <Route path="/EmployeeSalary" element={<EmpSalList/>} />

          <Route path="/DailyAttendance" element={<DailyAttendList/>} />
          <Route path="/dailyAttReport" element={<DailyAttendReport/>} />
          <Route path="/monthlysummaryreport" element={<MonthlySummaryReport/>} />

          <Route path="/LeaveConfiguration" element={<LeaveConfigList/>} />
          <Route path="/LeaveRequest" element={<LeaveReqList/>} />

         </Route>


      </Routes>
    </BrowserRouter>
    </>
  )
}

export default App
