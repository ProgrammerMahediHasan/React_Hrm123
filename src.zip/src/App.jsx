import { useState } from 'react'

import Layout from './Layout/Layout'
import CreateRole from './pages/roles/CreateRole'
import EditRole from './pages/roles/EditRole'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import RoleList from './pages/roles/RoleList'



import UserList from './pages/users/UserList'
import DeptList from './pages/department/DeptList'
import CreateDept from './pages/department/CreateDept'
import DesigList from './pages/designation/DesigList'
import EditDesig from './pages/designation/EditDesig'
import EditDept from './pages/department/EditDept'
import EmpList from './pages/employee/EmpList'
import CreateEmp from './pages/employee/CreateEmp'
import Dashboard from './pages/dashboard/Dashboard'
import DailyAttendList from './pages/daily_attendance/DailyAttendList'
// import LeaveConfigList from './pages/leave_configuration/LeaveConfigList'
// import LeaveReqList from './pages/leave_request/LeaveReqList'
import EmployInfo from './pages/employee/EmployInfo'
import EmpSalList from './pages/employee_salary/EmpSalList'
import DailyAttendReport from './pages/daily_attendance/DailyAttendReport'
import MonthlySummaryReport from './pages/daily_attendance/MonthlySummaryReport'
import PaySumRep from './pages/employee_salary/PaySumRep'
import EditUser from './pages/users/EditUser'
import CreateUser from './pages/users/CreateUser'
import CreateDesig from './pages/designation/CreateDesig'
import EditEmp from './pages/employee/EditEmp'
import CreateDailyAttendance from './pages/daily_attendance/CreateDailyAttendance'
import EditDailyAttendance from './pages/daily_attendance/EditDailyAttendance'
// import CreateLeaveConfig from './pages/leave_configuration/CreateLeaveConfig'
// import EditLeaveConfig from './pages/leave_configuration/EditLeaveConfig'
// import CreateLeaveRequest from './pages/leave_request/CreateLeaveRequest'
import CreateEmpSal from './pages/employee_salary/CreateEmpSal'
import AttendanceLogList from './pages/attendance_log/AttendanceLogList'
import CreateAttendanceLog from './pages/attendance_log/CreateAttendanceLog'
import Counter from './Counter'
import EndDailyAttendance from './pages/daily_attendance/EndDailyAttendance'
import LeaveTypeList from './pages/leave_type/LeaveTypeList'
import LeaveAssignList from './pages/leave_assign/LeaveAssignList'
import CreateLeaveType from './pages/leave_type/CreateLeaveType'
import CreateLeaveAssign from './pages/leave_assign/CreateLeaveAssign'
import EditLeaveType from './pages/leave_type/EditLeaveType'
import EditLeaveAssign from './pages/leave_assign/EditLeaveAssign'
import RemainingLeaveReport from './pages/leave_assign/RemainingLeaveReport'
import LeaveRequestList from './pages/leave_request/LeaveRequestList'
import CreateLeaveRequest from './pages/leave_request/CreateLeaveRequest'
// import RemainingLeave from './pages/leave_configuration/RemainingLeave'







function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      
 <BrowserRouter>

      <Routes>
        <Route path="/" element={<Layout />} >


        <Route path="/role" element={<RoleList />} />
        <Route path="/role/edit/:roleId" element={<EditRole />} />
        <Route path="/role/create" element={<CreateRole />} />
        {/* <Route path="/employee" element={<EmployInfo />} /> */}


        <Route path="/user" element={<UserList />} />
        <Route path="/user/create" element={<CreateUser />} />
        <Route path="/user/edit/:userId" element={<EditUser />} />


        <Route path="/department" element={<DeptList />} />
        <Route path="/department/create" element={<CreateDept />} />
        <Route path="/department/edit/:deptId" element={<EditDept />} />


        <Route path="/designation" element={<DesigList />} />
        <Route path="/designation/edit/:desigId" element={<EditDesig />} />
        <Route path="/designation/create" element={<CreateDesig />} />

         <Route path="/employee" element={<EmpList />} />
         <Route path="/employInfo" element={<EmployInfo />} />
         <Route path="/employee/create" element={<CreateEmp />} />
         <Route path="/employee/edit/:empId" element={<EditEmp />} />
 
         <Route path="/" element={<Dashboard/>} />
         {/* <Route path="/" element={<role />} /> */}


          <Route path="/EmployeeSalary" element={<EmpSalList />} />
          <Route path="/EmployeeSalary/create" element={<CreateEmpSal />} />

          <Route path="/DailyAttendance" element={<DailyAttendList/>} />
          <Route path="/DailyAttendance/create" element={<CreateDailyAttendance/>} />
          <Route path="/DailyAttendance/end" element={<EndDailyAttendance/>} />
          <Route path="/dailyAttReport" element={<DailyAttendReport/>} />
          <Route path="/monthlysummaryreport" element={<MonthlySummaryReport/>} />

          <Route path="/LeaveRequest" element={<LeaveRequestList />} />
          <Route path="/LeaveRequest/create" element={<CreateLeaveRequest />} />
      {/*     <Route path="/LeaveConfiguration/create" element={<CreateLeaveConfig />} />
          <Route path="/LeaveConfiguration/edit/:leaveconfigId" element={<EditLeaveConfig />} /> */}

          {/* <Route path="/RemainingLeave" element={<RemainingLeave/>} /> */}


           <Route path="/LeaveType" element={<LeaveTypeList/>} />
           <Route path="/LeaveType/create" element={<CreateLeaveType/>} />
           <Route path="/LeaveType/edit/:Id" element={<EditLeaveType />} />

           <Route path="/leaveassign" element={<LeaveAssignList/>} />
           <Route path="/leaveassign/edit/:Id" element={<EditLeaveAssign />} />
           <Route path="/leaveassign/create" element={<CreateLeaveAssign/>} />
           <Route path="/leaveassignreport" element={<RemainingLeaveReport/>} />
 
          <Route path="/AttendanceLog" element={<AttendanceLogList />} />
          <Route path="/AttendanceLog/create" element={<CreateAttendanceLog />} />


          <Route path="/counter" element={<Counter />} />




          <Route path="/DailyAttendance/edit/:dailyattId" element={<EditDailyAttendance/>} />

       



          <Route path="/payroll_summary" element={<PaySumRep/>} />

         </Route>


      </Routes>
    </BrowserRouter>
    </>
  )
}

export default App
