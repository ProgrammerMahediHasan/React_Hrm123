import React,{ useReducer, useState} from "react";
// import { Countreducer, initialState } from "./CountReducer";

const Counter = () => {
    const [Counter, setCounter] = useState(0)
    const intitialState={
        loading:false,
        count:0,
        err:false
    }

    const CountReducer = (state, action)=>{
        switch (action.type){
            case "add":
                return{...state, count: state.count + 1};
                
            case "sub":
                return{...state, count: state.count - 1};

            case "addNumber":
                return{...state, count: state.count + action.payload};

                default:
                    return state;
        }
    }

const [state, dispatch] = useReducer (CountReducer, intitialState);

const add = () => {
    // let abc = counter + 1;
    // setCounter(abc);

dispatch ({type:"add"});
}

const sub = () => {
    // let abc = counter - 1;
    // setCounter(abc);
    dispatch ({type:"sub"});
}

return (
    <>
    <h1>{state.count}</h1>
     
     <button onClick={add} className='btn btn-primary'>Add </button>
     <button onClick={sub} className='btn btn-primary'>Sub </button>
     <button onClick={()=> addNumber(5)} className='btn btn-primary'>Add Number</button>


    </>
)}
export default Counter