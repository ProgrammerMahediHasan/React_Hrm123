import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateLeaveConfig = () => {
  const navigate = useNavigate();

  // State for form data
  const [leave_configuration, setLeaveConfig] = useState({

    // id: '',
    leave_type: '',
    total_days: '',
    carry_forward: '',
    status: ''
  });

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setLeaveConfig((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/LeaveConfiguration/save',
      method: 'POST',
      data: leave_configuration
    })
      .then((res) => {
        if (res) navigate('/LeaveConfiguration');
      })
      .catch((err) => console.log(err));
  };

  // Handle back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
  style={{
    maxWidth: '100%',
    margin: '50px auto',
    padding: '40px 50px',
    border: '1px solid #ccc',
    borderRadius: '10px',
    backgroundColor: '#fff',
    boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
    fontSize: '15px',
    color: '#333',
  }}
>
  {/* Back Button */}
  <button
    onClick={handleBack}
    className="btn btn-secondary mb-4"
    style={{
      cursor: 'pointer',
      padding: '8px 15px',
      fontSize: '14px',
      borderRadius: '6px',
      boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
    }}
  >
    &larr; Back
  </button>

  <h1
    className="text-center mb-5"
    style={{ fontWeight: '600', color: '#222', letterSpacing: '0.04em' }}
  >
    <b>Create Leave Configuration</b>
  </h1>

  <form onSubmit={handleSubmit}>
    {/* ID */}
    {/* <div style={{ marginBottom: '22px' }}>
      <label htmlFor="id" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
        ID
      </label>
      <input
        type="text"
        id="id"
        name="id"
        value={leave_configuration.id}
        onChange={handleChange}
        placeholder="Enter ID"
        required
        style={{
          width: '700px',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
        }}
      />
    </div> */}

    {/* Leave Type */}
    <div style={{ marginBottom: '22px' }}>
      <label htmlFor="leave_type" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
        Leave Type
      </label>
      <input
        type="text"
        id="leave_type"
        name="leave_type"
        value={leave_configuration.leave_type}
        onChange={handleChange}
        placeholder="Enter leave type"
        required
        style={{
          width: '700px',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
        }}
      />
    </div>

    {/* Total Days */}
    <div style={{ marginBottom: '22px' }}>
      <label htmlFor="total_days" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
        Total Days
      </label>
      <input
        type="number"
        id="total_days"
        name="total_days"
        value={leave_configuration.total_days}
        onChange={handleChange}
        placeholder="Enter total days"
        required
        style={{
          width: '100%',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
        }}
      />
    </div>

    {/* Carry Forward */}
    <div style={{ marginBottom: '30px' }}>
      <label htmlFor="carry_forward" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
        Status
      </label>
      <select
        id="carry_forward"
        name="carry_forward"
        value={leave_configuration.carry_forward}
        onChange={handleChange}
        required
        style={{
          width: '100%',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          appearance: 'none',
          backgroundColor: '#fff',
        }}
      >
        <option value="">Select Carry Forward</option>
        <option value="Yes">Yes</option>
        <option value="No">No</option>
      </select>
    </div>

    {/* Description */}
    <div style={{ marginBottom: '22px' }}>
      <label htmlFor="description" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
        Description
      </label>
      <textarea
        id="description"
        name="description"
        value={leave_configuration.description}
        onChange={handleChange}
        placeholder="Enter description"
        required
        style={{
          width: '100%',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          minHeight: '80px',
        }}
      />
    </div>


    {/* Status */}
    <div style={{ marginBottom: '30px' }}>
      <label htmlFor="status" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
        Status
      </label>
      <select
        id="status"
        name="status"
        value={leave_configuration.status}
        onChange={handleChange}
        required
        style={{
          width: '100%',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          appearance: 'none',
          backgroundColor: '#fff',
        }}
      >
        <option value="">Select Status</option>
        <option value="Active">Active</option>
        <option value="Inactive">Inactive</option>
      </select>
    </div>

    {/* Submit Button */}
    <div style={{ textAlign: 'center' }}>
      <button
        type="submit"
        className="btn btn-primary"
        style={{
          fontSize: '15px',
          fontWeight: '600',
          padding: '12px 36px',
          borderRadius: '8px',
          boxShadow: '0 3px 14px rgba(74, 144, 226, 0.5)',
          cursor: 'pointer',
          transition: 'background-color 0.3s, box-shadow 0.3s',
        }}
      >
        Submit
      </button>
    </div>
  </form>
</div>

  );
};

export default CreateLeaveConfig;
