import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditLeaveConfig = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { leaveconfigId } = useParams();

  const [leave_configuration, setLeaveConfiguration] = useState({
    id: '',
    leave_type: '',
    total_days: '',
    carry_forward: '',
    description: '',
    status: '',
  });

  const navigate = useNavigate();

  // Fetch leave configuration by ID
  useEffect(() => {
    axios.get(`${baseUrl}/LeaveConfiguration/find/${leaveconfigId}`)
      .then(res => {
        const data = res.data.LeaveConfiguration || {};
        setLeaveConfiguration({
          id: data.id || '',
          leave_type: data.leave_type || '',
          total_days: data.total_days || '',
          carry_forward: data.carry_forward || '',
          description: data.description || '',
          status: data.status || '',
        });
      })
      .catch(err => console.log(err));
  }, [leaveconfigId]);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setLeaveConfiguration(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  const handleSubmit = (e) => {
    e.preventDefault();
    axios.put(`${baseUrl}/LeaveConfiguration/update/`, leave_configuration)
      .then(res => {
        console.log(res.data);
        navigate("/LeaveConfiguration");
      })
      .catch(err => console.log(err));
  };

  // Back button
  const handleBack = () => navigate(-1);

  return (
    <div style={{
      maxWidth: '100%',
      margin: '50px auto',
      padding: '40px 50px',
      border: '1px solid #ccc',
      borderRadius: '10px',
      backgroundColor: '#fff',
      boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      fontSize: '15px',
      color: '#333',
    }}>
      <button onClick={handleBack} className="btn btn-secondary mb-4">← Back</button>
      <h3 className="text-center mb-5"><b>Edit Leave Configuration</b></h3>

      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Leave Type</label>
          <input
            type="text"
            name="leave_type"
            value={leave_configuration.leave_type}
            onChange={handleChange}
            className="form-control"
            style={{ width: '700px', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Total Days</label>
          <input
            type="number"
            name="total_days"
            value={leave_configuration.total_days}
            onChange={handleChange}
            className="form-control"
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Carry Forward</label>
          <input
            type="number"
            name="carry_forward"
            value={leave_configuration.carry_forward}
            onChange={handleChange}
            className="form-control"
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Description</label>
          <textarea
            name="description"
            value={leave_configuration.description}
            onChange={handleChange}
            className="form-control"
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb', minHeight: '80px' }}
          />
        </div>

        <div style={{ marginBottom: '30px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Status</label>
          <select
            name="status"
            value={leave_configuration.status}
            onChange={handleChange}
            className="form-control"
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          >
            <option value="">Select status</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>

        <div style={{ textAlign: 'center' }}>
          <button type="submit" className="btn btn-success px-5">Update</button>
        </div>
      </form>
    </div>
  );
};

export default EditLeaveConfig;
