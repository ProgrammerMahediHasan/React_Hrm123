import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateDept = () => {
  const navigate = useNavigate();

  const [department, setDepartment] = useState({
    name: '',
    description: '',
    status: ''
  });

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setDepartment((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/department/save',
      method: 'POST',
      data: department
    })
      .then((res) => {
        if (res) navigate('/department');
      })
      .catch((err) => console.log(err));
  };

  // Handle back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
      style={{
        maxWidth: '100%',
        margin: '50px auto',
        padding: '40px 50px',
        border: '1px solid #ccc',
        borderRadius: '10px',
        backgroundColor: '#fff',
        boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        fontSize: '15px',
        color: '#333',
      }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-4"
        style={{
          cursor: 'pointer',
          padding: '8px 15px',
          fontSize: '14px',
          borderRadius: '6px',
          boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
        }}
      >
        &larr; Back
      </button>

      <h2
        className="text-center mb-5"
        style={{ fontWeight: '600', color: '#222', letterSpacing: '0.04em' }}
      >
        Create Department
      </h2>

      <form onSubmit={handleSubmit}>
        {/* Name */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="name" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Name
          </label>
          <input
            type="text"
            id="name"
            name="name"
            value={department.name}
            onChange={handleChange}
            placeholder="Enter name"
            required
            style={{
              width: '700px',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
              transition: 'border-color 0.3s',
            }}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          />
        </div>

        {/* Description */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="description" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Description
          </label>
          <input
            type="text"
            id="description"
            name="description"
            value={department.description}
            onChange={handleChange}
            placeholder="Enter description"
            required
            style={{
              width: '100%',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
              transition: 'border-color 0.3s',
            }}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          />
        </div>

        {/* Status */}
        <div style={{ marginBottom: '30px' }}>
          <label htmlFor="status" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Status
          </label>
          <select
            id="status"
            name="status"
            value={department.status}
            onChange={handleChange}
            required
            style={{
              width: '100%',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
              transition: 'border-color 0.3s',
              appearance: 'none',
              backgroundColor: '#fff',
            }}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          >
            <option value="">Select Status</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>

        {/* Submit Button */}
        <div style={{ textAlign: 'center' }}>
          <button
            type="submit"
            className="btn btn-primary"
            style={{
              fontSize: '15px',
              fontWeight: '600',
              padding: '12px 36px',
              borderRadius: '8px',
              boxShadow: '0 3px 14px rgba(74, 144, 226, 0.5)',
              cursor: 'pointer',
              transition: 'background-color 0.3s, box-shadow 0.3s',
            }}
            onMouseEnter={(e) => {
              e.target.style.backgroundColor = '#3a78d8';
              e.target.style.boxShadow = '0 6px 22px rgba(58, 120, 216, 0.8)';
            }}
            onMouseLeave={(e) => {
              e.target.style.backgroundColor = '';
              e.target.style.boxShadow = '0 3px 14px rgba(74, 144, 226, 0.5)';
            }}
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateDept;
