import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditDesig = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { deptId } = useParams();

  const [department, setDept] = useState({
    id: '',
    name: '',
    description: '',
    status: ''
  });

  const navigate = useNavigate();

  // Fetch user data
  function fetchDesig() {
   axios({
  url: `${baseUrl}/department/find/${deptId}`,
  method: "GET",
  data: {}
})
.then((res) => {
  console.log(res.data.department);
  setDept({
    id: res.data.department.id,
    name: res.data.department.name,
    description: res.data.department.description
  });
})

      .catch((err) => { console.log(err) });
  }

  useEffect(() => {
    fetchDesig();
  }, []);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setDept(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  function handleSubmit(e) {
    e.preventDefault();

    axios({
      url: `${baseUrl}/department/update`,
      method: "PUT",
      data:  department 
    })
      .then((res) => {
        console.log(res.data);
        navigate("/department");
      })
      .catch((err) => { console.log(err) });
  }

  // Back button
  const handleBack = () => {
    navigate(-1);
  };

  return (


<div
  style={{
    maxWidth: '100%',
    margin: '50px auto',
    padding: '40px 50px',
    border: '1px solid #ccc',
    borderRadius: '10px',
    backgroundColor: '#fff',
    boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
    fontSize: '15px',
    color: '#333',
  }}
>
  {/* Back Button */}
  <button
    onClick={handleBack}
    className="btn btn-secondary mb-4"
    style={{
      cursor: 'pointer',
      padding: '8px 15px',
      fontSize: '14px',
      borderRadius: '6px',
      boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
    }}
  >
    &larr; Back
  </button>

  <h2
    className="text-center mb-5"
    style={{ fontWeight: '600', color: '#222', letterSpacing: '0.04em' }}
  >
    Edit Department
  </h2>

  <form onSubmit={handleSubmit}>
    {/* Name */}
    <div style={{ marginBottom: '22px' }}>
      <label
        style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}
      >
        Name
      </label>
      <input
        type="text"
        name="name"
        value={department.name}
        onChange={handleChange}
        required
        style={{
          width: '700px',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          transition: 'border-color 0.3s',
        }}
      />
    </div>

    {/* Description */}
    <div style={{ marginBottom: '22px' }}>
      <label
        style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}
      >
        Description
      </label>
      <input
        type="text"
        name="description"
        value={department.description}
        onChange={handleChange}
        required
        style={{
          width: '100%',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          transition: 'border-color 0.3s',
        }}
      />
    </div>

    {/* Status */}
    <div style={{ marginBottom: '30px' }}>
      <label
        style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}
      >
        Status
      </label>
      <select
        name="status"
        value={department.status}
        onChange={handleChange}
        required
        style={{
          width: '100%',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          backgroundColor: '#fff',
        }}
      >
        <option value="">Select status</option>
        <option value="Active">Active</option>
        <option value="Inactive">Inactive</option>
      </select>
    </div>

    {/* Submit */}
    <div style={{ textAlign: 'center' }}>
      <button
        type="submit"
        className="btn btn-success"
        style={{
          fontSize: '15px',
          fontWeight: '600',
          padding: '12px 36px',
          borderRadius: '8px',
        }}
      >
        Update
      </button>
    </div>
  </form>
</div>




  );
};

export default EditDesig;
