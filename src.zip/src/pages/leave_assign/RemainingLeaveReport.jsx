import axios from "axios";
import React, { useEffect, useState } from "react";

const RemainingLeaveReport = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;

  const [year, setYear] = useState("");
  const [empId, setEmpId] = useState("");
  const [employees, setEmployees] = useState([]);
  const [report, setReport] = useState([]);
  const [searched, setSearched] = useState(false);

  // ✅ Load employee list
  useEffect(() => {
    axios.get(`${baseUrl}/employee`)
      .then(res => setEmployees(res.data.employees || []))
      .catch(err => console.log(err));
  }, []);

  // ✅ Search button click
  const handleSearch = () => {

    // ❌ Year must be selected
    if (!year) {
      alert("Please select Year");
      return;
    }

    axios.get(`${baseUrl}/leaveassign`)
      .then(res => {
        const allData = res.data.leave_assign || [];

        const filtered = allData.filter(la => {
          if (la.year != year) return false;
          if (empId && la.emp_id != empId) return false;
          return true;
        });

        setReport(filtered);
        setSearched(true);
      })
      .catch(err => console.log(err));
  };

  return (
    <div style={{ padding: "30px" }}>

      <h3 className="text-center mb-4"><b>Remaining Leave Report</b></h3>

      {/* ================= FILTER ================= */}
      <div
        style={{
          background: "#fff",
          padding: "15px",
          borderRadius: "8px",
          marginBottom: "20px",
        }}
      >
        <b>Year:</b>{" "}
        <select value={year} onChange={e => setYear(e.target.value)}>
          <option value="">Select Year</option>
          {Array.from({ length: 6 }, (_, i) => {
            const y = new Date().getFullYear() - i;
            return <option key={y} value={y}>{y}</option>;
          })}
        </select>

        &nbsp;&nbsp;&nbsp;

        {/* <b>Employee:</b>{" "}
        <select value={empId} onChange={e => setEmpId(e.target.value)}>
          <option value="">All Employee</option>
          {employees.map(emp => (
            <option key={emp.id} value={emp.id}>
              {emp.name}
            </option>
          ))}
        </select> */}

        &nbsp;&nbsp;&nbsp;

        <button onClick={handleSearch}>Search</button>
      </div>

      {/* ================= TABLE ================= */}


    <div className="container">


          <table className="table table-bordered table-striped">
            <thead className="text-white"
                style={{ backgroundColor: "#0c3f7aea", fontSize: "0.88rem" }}>
          <tr>
            <th>Employee Name</th>
            <th>Leave Type</th>
            <th>Allowed</th>
            <th>Used</th>
            <th>Remaining</th>
            <th>Year</th>
          </tr>
        </thead>

        <tbody>
          {!searched && (
            <tr>
              <td colSpan="6" className="text-center">
                Please select Year and click Search
              </td>
            </tr>
          )}

          {searched && report.length === 0 && (
            <tr>
              <td colSpan="6" className="text-center">
                No data found
              </td>
            </tr>
          )}

          {report.map((la, index) => (
            <tr key={index}>
              <td>{la.emp_name}</td>
              <td>{la.leave_type_id}</td>
              <td>{la.allow_days}</td>
              <td>{la.used_days}</td>
              <td>{la.allow_days - la.used_days}</td>
              <td>{la.year}</td>
            </tr>
          ))}
        </tbody>
      </table>


</div>
    </div>
  );
};

export default RemainingLeaveReport;
