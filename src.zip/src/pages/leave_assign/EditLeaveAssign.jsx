import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const EditLeaveAssign = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { Id } = useParams();
  const navigate = useNavigate();

  const [leave_assign, setLeaveAssign] = useState({
    id: "",
    emp_id: "",
    leave_type_id: "",
    allow_days: "",
    used_days: "",
    year: "",
  });

  // ✅ Fetch leave assign by ID
  const fetchLeaveAssign = () => {
    axios({
      url: `${baseUrl}/leaveassign/find/${Id}`,
      method: "GET",
    })
      .then((res) => {
        console.log(res.data); // check API response
        const la = res.data?.leaveassign; // ✅ correct key from API
        if (!la) {
          console.log("No data found for this ID");
          return;
        }

        setLeaveAssign({
          id: la.id,
          emp_id: la.emp_id,
          leave_type_id: la.leave_type_id,
          allow_days: la.allow_days,
          used_days: la.used_days,
          year: la.year,
        });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    fetchLeaveAssign();
  }, []);

  // ✅ Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setLeaveAssign((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // ✅ Handle update submit
  const handleSubmit = (e) => {
    e.preventDefault();

    axios({
      url: `${baseUrl}/leaveassign/update/${Id}`,
      method: "PUT",
      data: leave_assign,
    })
      .then(() => {
        navigate("/leaveassign");
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // ✅ Back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
      style={{
        maxWidth: "900px",
        margin: "50px auto",
        padding: "40px",
        border: "1px solid #ccc",
        borderRadius: "10px",
        backgroundColor: "#fff",
        boxShadow: "0 5px 15px rgba(0,0,0,0.1)",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        fontSize: "15px",
        color: "#333",
      }}
    >
      {/* Back Button */}
      <button onClick={handleBack} className="btn btn-secondary mb-4">
        ← Back
      </button>

      <h3 className="text-center mb-4">
        <b>Edit Leave Assign</b>
      </h3>

      <form onSubmit={handleSubmit}>
        {/* Hidden ID */}
        <input type="hidden" name="id" value={leave_assign.id} />

        {/* Employee ID */}
        <div className="mb-3">
          <label className="fw-semibold">Employee ID</label>
          <input
            style={{
              width: "700px",
              padding: "11px 14px",
              fontSize: "14px",
              borderRadius: "6px",
              border: "1.3px solid #bbb",
            }}
            type="text"
            name="emp_id"
            value={leave_assign.emp_id}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        {/* Leave Type ID */}
        <div className="mb-3">
          <label className="fw-semibold">Leave Type ID</label>
          <input
            type="text"
            name="leave_type_id"
            value={leave_assign.leave_type_id}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        {/* Allow Days */}
        <div className="mb-3">
          <label className="fw-semibold">Allow Days</label>
          <input
            type="number"
            name="allow_days"
            value={leave_assign.allow_days}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        {/* Used Days */}
        <div className="mb-3">
          <label className="fw-semibold">Used Days</label>
          <input
            type="number"
            name="used_days"
            value={leave_assign.used_days}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        {/* Year */}
        <div className="mb-3">
          <label className="fw-semibold">Year</label>
          <input
            type="number"
            name="year"
            value={leave_assign.year}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        {/* Submit */}
        <div className="text-center">
          <button type="submit" className="btn btn-success px-5">
            Update
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditLeaveAssign;
