import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateLeaveAssign = () => {
  const navigate = useNavigate();

  const [leave_assign, setleave_assign] = useState({
    emp_id: '',
    leave_type_id: '',
    allow_days: '',
    used_days: '',
    year: ''
  });

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setleave_assign((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/leaveassign/save',
      method: 'POST',
      data: leave_assign
    })
      .then((res) => {
        if (res) navigate('/leaveassign');
      })
      .catch((err) => console.error(err));
  };

  // Handle back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
      style={{
        maxWidth: '100%',
        margin: '50px auto',
        padding: '40px 50px',
        border: '1px solid #ccc',
        borderRadius: '10px',
        backgroundColor: '#fff',
        boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        fontSize: '15px',
        color: '#333',
      }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-4"
        style={{
          cursor: 'pointer',
          padding: '8px 15px',
          fontSize: '14px',
          borderRadius: '6px',
          boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
        }}
      >
        &larr; Back
      </button>

      <h2
        className="text-center mb-5"
        style={{ fontWeight: '600', color: '#222', letterSpacing: '0.04em' }}
      >
        Create Leave Type
      </h2>

     
<form onSubmit={handleSubmit}>
  {/* Employee ID */}
  <div style={{ marginBottom: '22px' }}>
    <label htmlFor="emp_id" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
      Employee ID
    </label>
    <input
      type="text"
      id="emp_id"
      name="emp_id"
      value={leave_assign.emp_id}
      onChange={handleChange}
      placeholder="Enter Employee ID"
      required
      style={{ width: '700px', padding: '11px 14px', fontSize: '14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
    />
  </div>

  {/* Leave Type ID */}
  <div style={{ marginBottom: '22px' }}>
    <label htmlFor="leave_type_id" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
      Leave Type ID
    </label>
    <input
      type="text"
      id="leave_type_id"
      name="leave_type_id"
      value={leave_assign.leave_type_id}
      onChange={handleChange}
      placeholder="Enter Leave Type ID"
      required
      style={{ width: '700px', padding: '11px 14px', fontSize: '14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
    />
  </div>

  {/* Allow Days */}
  <div style={{ marginBottom: '22px' }}>
    <label htmlFor="allow_days" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
      Allowed Days
    </label>
    <input
      type="number"
      id="allow_days"
      name="allow_days"
      value={leave_assign.allow_days}
      onChange={handleChange}
      placeholder="Enter allowed days"
      required
      style={{ width: '700px', padding: '11px 14px', fontSize: '14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
    />
  </div>

  {/* Used Days */}
  <div style={{ marginBottom: '22px' }}>
    <label htmlFor="used_days" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
      Used Days
    </label>
    <input
      type="number"
      id="used_days"
      name="used_days"
      value={leave_assign.used_days}
      onChange={handleChange}
      placeholder="Enter used days"
      style={{ width: '700px', padding: '11px 14px', fontSize: '14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
    />
  </div>

  {/* Year */}
  <div style={{ marginBottom: '22px' }}>
    <label htmlFor="year" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
      Year
    </label>
    <input
      type="number"
      id="year"
      name="year"
      value={leave_assign.year}
      onChange={handleChange}
      placeholder="Enter year"
      required
      style={{ width: '700px', padding: '11px 14px', fontSize: '14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
    />
  </div>

  {/* Submit Button */}
  <div style={{ textAlign: 'center' }}>
    <button
      type="submit"
      className="btn btn-primary"
      style={{ fontSize: '15px', fontWeight: '600', padding: '12px 36px', borderRadius: '8px', cursor: 'pointer' }}
    >
      Submit
    </button>
  </div>
</form>


    </div>
  );
};

export default CreateLeaveAssign;
