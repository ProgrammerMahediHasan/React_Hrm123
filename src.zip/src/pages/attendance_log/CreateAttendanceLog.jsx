import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateAttendanceLog = () => {
  const [attendance_logs, setAttendanceLog] = useState({
    id: '',
    source: '',
    in_time: '',
    out_time: '',
    status: '',
    grace_time: '', // Buffer time in minutes
    late_time: '',
    total_work_minutes: '',
    remarks: ''
  });

  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setAttendanceLog((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  const handleBack = () => navigate(-1);

  const inputStyle = {
    width: '100%',
    padding: '11px 14px',
    fontSize: '14px',
    borderRadius: '6px',
    border: '1.3px solid #bbb',
    transition: 'border-color 0.3s',
  };

  const selectStyle = { ...inputStyle, appearance: 'none', backgroundColor: '#fff' };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();

    // Late calculation based on in_time and grace_time
    if (attendance_logs.in_time) {
      const [inH, inM] = attendance_logs.in_time.split(':').map(Number);
      const inMinutes = inH * 60 + inM;

      const startMinutes = 9 * 60; // 09:00 AM start
      const grace = Number(attendance_logs.grace_time || 0); // grace time in minutes
      const bufferEnd = startMinutes + grace;

      let late = 0;
      if (inMinutes > bufferEnd) {
        late = inMinutes - startMinutes; // Late counted from 9:00 AM
      }

      setAttendanceLog((prev) => ({
        ...prev,
        late_time: late
      }));
    }

    // Submit after setting late_time
    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/AttendanceLog/save/',
      method: 'POST',
      data: attendance_logs
    })
      .then((res) => {
        if (res) navigate('/AttendanceLog');
      })
      .catch((err) => console.log(err));
  };

  return (
    <div
      style={{
        maxWidth: '700px',
        margin: '50px auto',
        padding: '40px 50px',
        border: '1px solid #ccc',
        borderRadius: '10px',
        backgroundColor: '#fff',
        boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        fontSize: '15px',
        color: '#333',
      }}
    >
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-4"
        style={{ cursor: 'pointer', padding: '8px 15px', fontSize: '14px', borderRadius: '6px' }}
      >
        &larr; Back
      </button>

      <h2 className="text-center mb-5" style={{ fontWeight: '600', color: '#222' }}>
        Create Attendance Log
      </h2>

      <form onSubmit={handleSubmit}>

        {/* Source */}
        <div style={{ marginBottom: '22px' }}>
          <label>Source</label>
          <select
            name="source"
            value={attendance_logs.source}
            onChange={handleChange}
            style={{
              width: '700px',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
              transition: 'border-color 0.3s',
            }}
          >
            <option value="">Select Source</option>
            <option value="Biometric">Biometric</option>
            <option value="Manual">Manual</option>
            <option value="Web">Web</option>
          </select>
        </div>

        {/* In Time */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>In Time</label>
          <input
            type="time"
            name="in_time"
            value={attendance_logs.in_time}
            onChange={handleChange}
            style={inputStyle}
          />
        </div>

        {/* Out Time */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Out Time</label>
          <input
            type="time"
            name="out_time"
            value={attendance_logs.out_time}
            onChange={handleChange}
            style={inputStyle}
          />
        </div>

        {/* Status
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Status</label>
          <select
            name="status"
            value={attendance_logs.status}
            onChange={handleChange}
            style={selectStyle}
          >
            <option value="">Select Status</option>
            <option value="Working-Day">Working-Day</option>
            <option value="Weekend">Weekend</option>
            <option value="Holiday">Holiday</option>
          </select>
        </div> */}

        {/* Grace Time */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Grace Time (minutes)</label>
          <input
            type="time"
            name="grace_time"
            value={attendance_logs.grace_time}
            onChange={handleChange}
            style={inputStyle}
            placeholder="Enter grace time (e.g., 10)"
          />
        </div>

        {/* Late Time */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Late Time (minutes)</label>
          <input
            type="time"
            name="late_time"
            value={attendance_logs.late_time}
            // readOnly
            style={inputStyle}
            onChange={handleChange}
            placeholder="Late time will auto calculate"
          />
        </div>

        {/* Total Work Minutes */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Total Work Minutes</label>
          <input
            type="number"
            name="total_work_minutes"
            value={attendance_logs.total_work_minutes}
            onChange={handleChange}
            style={inputStyle}
            placeholder="Enter total work minutes"
          />
        </div>

        {/* Remarks */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Remarks</label>
          <textarea
            name="remarks"
            rows="3"
            value={attendance_logs.remarks}
            onChange={handleChange}
            style={inputStyle}
            placeholder="Write remarks"
          ></textarea>
        </div>

        {/* Submit */}
        <div style={{ textAlign: 'center' }}>
          <button
            type="submit"
            className="btn btn-primary"
            style={{ fontSize: '15px', fontWeight: '600', padding: '12px 36px', borderRadius: '8px', cursor: 'pointer' }}
          >
            Submit
          </button>
        </div>

      </form>
    </div>
  );
};

export default CreateAttendanceLog;
