import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';

const LeaveTypeList = () => {


const [leave_types, setLeaveType] = useState([])
const baseUrl=import.meta.env.VITE_BASE_URL;

function getLeaveType (){

axios(
    { url: `${baseUrl}/leavetype`,
      method: "GET",
      data: {}
    })

.then (res=>{
    console.log(res.data);
    setLeaveType(res.data.leave_types);
    // setloading(false);
})

.catch (err =>{
console.log(err.data);
});
};


useEffect (
    () =>{
        getLeaveType ()
    } ,[]);



// Delete Function 

   const deleteleave_types = (id) => {
   const Delete = window.confirm ("Are you want to delete this Leave Type?");
   if (!Delete) return;

axios(
    { url: `${baseUrl}/leavetype/delete/` ,
      method: "DELETE",
      data: {id}
    })

.then(() => {
        getLeaveType();
      })

.catch(err => console.log(err));
  };

   


  return (
    
<>
  <h1 className="text-center my-4">Create Leave Type</h1>

  <div className="container" >
    <div className="d-flex justify-content-between align-items-center mb-4"></div>
    <Link to="/LeaveType/create" className="btn btn-success my-3">
      Add Leave Type
    </Link>
  </div>

  <div className="container">
    <table className="table table-bordered table-striped">
      <thead
        className="text-white"
        style={{ backgroundColor: "#0c3f7aea", fontSize: "0.88rem" }}
      >
        <tr>
          <th>Id</th>
          <th>Leave Name</th>
          <th>Leave Code</th>
          <th>Total Leave Days</th>
          <th>Description</th>
          <th>Leave Status</th>
          <th>Action</th>
        </tr>
      </thead>

      <tbody>
        {leave_types.map((LeaveType, i) => (
          <tr key={i}>
            <td>{LeaveType.id}</td>
            <td>{LeaveType.leave_name}</td>
            <td>{LeaveType.leave_code}</td>
            <td>{LeaveType.total_days}</td>
            <td>{LeaveType.description}</td>
            <td>{LeaveType.status}</td>

   {/* Action Buttons */}
   <td style={{ display: "flex", gap: "8px" }}>
   {/* Edit Button */}
{/* <Link to={`/LeaveType/edit/${LeaveType.id}`} className="btn btn-info"></Link> */}

   <Link to={`/leavetype/edit/${LeaveType.id}`}
         className="btn btn-info"
         style={{width: "40px", height: "40px", display: "flex", justifyContent: "center", alignItems: "center", padding: "0",}} >
         <i className="bi bi-pencil-square"></i> </Link>

    {/* Delete Button */}
    <button onClick={() => deleteleave_types(LeaveType.id)}
            className="btn btn-danger"
            style={{ width: "40px", height: "40px", display: "flex", justifyContent: "center",  alignItems: "center",  padding: "0", }} >
                <i className="bi bi-trash"></i>
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
</>



  )
}

export default LeaveTypeList;