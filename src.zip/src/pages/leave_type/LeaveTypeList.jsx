import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import "./pagination.css";
const LeaveTypeList = () => {

  const [leave_types, setLeaveType] = useState([]);


  const getLeaveType = () => {
    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/LeaveType/",
      method: "GET",
      data: {}
    })
      .then((res) => {
        setLeaveType(res.data.leave_types);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    getLeaveType();
  }, []);

  // ✅ Delete function
  const deleteleave_types = (id) => {
    const Delete = window.confirm("Are you sure you want to delete this Leave Types?");
    if (!Delete) return;

    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/AttendanceLog/delete/",
      method: "DELETE",
      data: { id }
    })
      .then(() => {
        getLeaveType();
      })
      .catch(err => console.log(err));
  };

  // ✅ Pagination States
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 6;


  // ✅ Pagination Logic
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = leave_types.slice(indexOfFirstRow, indexOfLastRow);

  const totalPages = Math.ceil(leave_types.length / rowsPerPage);

  return (
    <>
      <h1 className="text-center my-4">Leave Types</h1>

      <div className="container" style={{ paddingBottom: "80px" }}>
        <div className="d-flex justify-content-between align-items-center mb-4">
          <Link to="/LeaveType/create" className="btn btn-success">
            Add Leave Type
          </Link>
        </div>

        <div className="container">
          <table className="table table-bordered table-striped">
            <thead className="text-white"
                style={{ backgroundColor: "#0c3f7aea", fontSize: "0.88rem" }}>
              <tr>
                {/* <th>Emp ID</th> */}
                <th>Id</th>
                <th>Leave Name</th>
                <th>Leave Code</th>
                {/* <th>Status</th> */}
                <th>Allow Days</th>
                <th>Description</th>
                <th>Leave Status</th>
                <th>Actions</th>

              
              </tr>
            </thead>

            <tbody>
              {currentRows.map((LeaveType, i) => (
                <tr key={i}>
                  {/* <td>{DailyAttendance.id}</td> */}
                  <td>{LeaveType.id}</td>
                  <td>{LeaveType.leave_name}</td>
                  <td>{LeaveType.leave_code}</td>
                  {/* <td>{AttendanceLog.status}</td> */}
                  <td>{LeaveType.total_days}</td>
                  <td>{LeaveType.description}</td>
                  <td>{LeaveType.status}</td>
                  <td>
                    
                   {/* Edit button with icon */}
                  <Link to={`/LeaveType/edit/${leave_types.emp_id}`} className="btn btn-info me-2" 
                  style={{ width: "50px", display: "flex", justifyContent: "center" }}>
                    <i className="bi bi-pencil-square"></i>
                  </Link>
                 {/* Delete button with icon */}
                <button
                  onClick={() => deleteleave_types(LeaveType.emp_id)}
                  className="btn btn-danger"
                  style={{ width: "50px", display: "flex", justifyContent: "center" }}>
                  <i className="bi bi-trash"></i>
                </button>


                  </td>
                </tr>
              ))}
            </tbody>
          </table>


{/* Pagination  */}


<div className="pagination">

  <a
    className={currentPage === 1 ? "disabled" : ""}
    onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
  >
    « Previous
  </a>

  {[...Array(totalPages)].map((_, index) => (
    <a
      key={index}
      className={currentPage === index + 1 ? "active" : ""}
      onClick={() => setCurrentPage(index + 1)}
    >
      {index + 1}
    </a>
  ))}

  <a
    className={currentPage === totalPages ? "disabled" : ""}
    onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
  >
    Next »
  </a>

</div>

        

        </div>
      </div>
    </>
  );
};

export default LeaveTypeList;
