import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

const EditLeaveType = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { Id } = useParams();
  const navigate = useNavigate();

  const [leave_types, setLeaveType] = useState({
    id: "",
    leave_name: "",
    leave_code: "",
    total_days: "",
    description: "",
    status: "",
  });

  // ✅ Fetch leave type by ID
  const fetchLeaveType = () => {
    axios({
      url: `${baseUrl}/leavetype/find/${Id}`,
      method: "GET",
    })
      .then((res) => {
        // ✅ API sends "leavetype"
        const lt = res.data?.leavetype;

        if (!lt) return;

        setLeaveType({
          id: lt.id,
          leave_name: lt.leave_name,
          leave_code: lt.leave_code,
          total_days: lt.total_days,
          description: lt.description,
          status: lt.status,
        });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    fetchLeaveType();
  }, []);

  // ✅ Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setLeaveType((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // ✅ Handle update submit
  const handleSubmit = (e) => {
    e.preventDefault();

    axios({
      url: `${baseUrl}/leavetype/update/${Id}`,
      method: "PUT",
      data: leave_types,
    })
      .then(() => {
        navigate("/leavetype");
      })
      .catch((err) => {
        console.log(err);
      });
  };

  // ✅ Back
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
      style={{
        maxWidth: "900px",
        margin: "50px auto",
        padding: "40px",
        border: "1px solid #ccc",
        borderRadius: "10px",
        backgroundColor: "#fff",
        boxShadow: "0 5px 15px rgba(0,0,0,0.1)",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        fontSize: "15px",
        color: "#333",
      }}
    >
      {/* Back Button */}
      <button onClick={handleBack} className="btn btn-secondary mb-4">
        ← Back
      </button>

      <h3 className="text-center mb-4">
        <b>Edit Leave Type</b>
      </h3>

      <form onSubmit={handleSubmit}>
        {/* Hidden ID */}
        <input type="hidden" name="id" value={leave_types.id} />

        {/* Leave Name */}
        <div className="mb-3">
          <label className="fw-semibold">Leave Name</label>
          <input

          style={{
              width: '700px',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
              transition: 'border-color 0.3s',
            }}
            type="text"
            name="leave_name"
            value={leave_types.leave_name}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        {/* Leave Code */}
        <div className="mb-3">
          <label className="fw-semibold">Leave Code</label>
          <input
            type="text"
            name="leave_code"
            value={leave_types.leave_code}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        {/* Total Days */}
        <div className="mb-3">
          <label className="fw-semibold">Total Days</label>
          <input
            type="number"
            name="total_days"
            value={leave_types.total_days}
            onChange={handleChange}
            className="form-control"
            required
          />
        </div>

        {/* Description */}
        <div className="mb-3">
          <label className="fw-semibold">Description</label>
          <textarea
            name="description"
            value={leave_types.description}
            onChange={handleChange}
            className="form-control"
            rows="3"
          />
        </div>

        {/* Status */}
        <div className="mb-4">
          <label className="fw-semibold">Status</label>
          <select
            name="status"
            value={leave_types.status}
            onChange={handleChange}
            className="form-control"
            required
          >
            <option value="">Select status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>

        {/* Submit */}
        <div className="text-center">
          <button type="submit" className="btn btn-success px-5">
            Update
          </button>
        </div>
      </form>
    </div>
  );
};

export default EditLeaveType;
