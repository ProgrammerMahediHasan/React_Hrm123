import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateLeaveType = () => {
  const navigate = useNavigate();

  const [leave_types, setLeaveTypes] = useState({
    leave_name: '',
    leave_code: '',
    total_days: '',
    description: '',
    status: ''
  });

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setLeaveTypes((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/LeaveType/save',
      method: 'POST',
      data: leave_types
    })
      .then((res) => {
        if (res) navigate('/LeaveType');
      })
      .catch((err) => console.error(err));
  };

  // Handle back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
      style={{
        maxWidth: '100%',
        margin: '50px auto',
        padding: '40px 50px',
        border: '1px solid #ccc',
        borderRadius: '10px',
        backgroundColor: '#fff',
        boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        fontSize: '15px',
        color: '#333',
      }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-4"
        style={{
          cursor: 'pointer',
          padding: '8px 15px',
          fontSize: '14px',
          borderRadius: '6px',
          boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
        }}
      >
        &larr; Back
      </button>

      <h2
        className="text-center mb-5"
        style={{ fontWeight: '600', color: '#222', letterSpacing: '0.04em' }}
      >
        Create Leave Type
      </h2>

      <form onSubmit={handleSubmit}>
        {/* Leave Name */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="leave_name" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Leave Name
          </label>
          <input
            type="text"
            id="leave_name"
            name="leave_name"
            value={leave_types.leave_name}
            onChange={handleChange}
            placeholder="Enter leave name"
            required
            style={{
              width: '700px',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
            }}
          />
        </div>

        {/* Leave Code */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="leave_code" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Leave Code
          </label>
          <input
            type="text"
            id="leave_code"
            name="leave_code"
            value={leave_types.leave_code}
            onChange={handleChange}
            placeholder="Enter leave code"
            required
            style={{
              width: '700px',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
            }}
          />
        </div>

        {/* Total Days */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="total_days" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Total Days
          </label>
          <input
            type="number"
            id="total_days"
            name="total_days"
            value={leave_types.total_days}
            onChange={handleChange}
            placeholder="Enter total days"
            required
            style={{
              width: '700px',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
            }}
          />
        </div>

        {/* Description */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="description" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Description
          </label>
          <input
            type="text"
            id="description"
            name="description"
            value={leave_types.description}
            onChange={handleChange}
            placeholder="Enter description"
            style={{
              width: '700px',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
            }}
          />
        </div>

        {/* Status */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="status" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Status
          </label>
          <select
            id="status"
            name="status"
            value={leave_types.status}
            onChange={handleChange}
            style={{
              width: '700px',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
            }}
            required
          >
            <option value="">Select Status</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>

        {/* Submit Button */}
        <div style={{ textAlign: 'center' }}>
          <button
            type="submit"
            className="btn btn-primary"
            style={{
              fontSize: '15px',
              fontWeight: '600',
              padding: '12px 36px',
              borderRadius: '8px',
              cursor: 'pointer',
            }}
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateLeaveType;
