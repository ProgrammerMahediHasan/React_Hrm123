import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
// import Header from '../../Layout/Header';
// import Footer from '../../Layout/Footer';

const EmpSalList = () => {

  const getEmployeeSalary = () => {
    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/EmployeeSalary/",
      method: "GET",
      data: {}
    })
      .then((res) => {
        console.log(res.data.employee_salary);
        setEmployeeSalary(res.data.employee_salary)
      })
      .catch((err) => {
        console.log(err);
      });
  }

  const [employee_salary, setEmployeeSalary] = useState([]);

  useEffect (() => {getEmployeeSalary()},[]);

  // Delete function 
  const deleteemployee_salary = (id) => {
    const Delete = window.confirm("Are you sure you want to delete this Employee Salary?");
    if (!Delete) return;

    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/EmployeeSalary/delete/",
      method: "DELETE",
      data: { id }
    })
      .then(res => {
        console.log(res.data.employee_salary);
        getEmployeeSalary(); // refresh table after delete
      })
      .catch(err => console.log(err));
  };


 // ✅ Pagination States
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 6;


  // ✅ Pagination Logic
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = employee_salary.slice(indexOfFirstRow, indexOfLastRow);

  const totalPages = Math.ceil(employee_salary.length / rowsPerPage);


  return (
    
<>

{/* <Header /> */}
  <h1 className="text-center my-4">Add Employee Salary</h1>

  <div className="container" style={{ paddingBottom: "80px" }}>
        {/* Create Button */}
        <div className="d-flex justify-content-between align-items-center mb-4">
          <Link to="/EmployeeSalary/create" className="btn btn-success">
            Add Employee
          </Link>
        </div>

  <div className="container">
    <table className="table table-bordered table-striped">
      <thead className="text-white"
                style={{ backgroundColor: "#0c3f7aea", fontSize: "0.88rem" }}
      >
        <tr>
          {/* <th scope="col">SLNO</th> */}
          <th scope="col">Emp Id</th>
          <th scope="col">Basic Salary</th>
          <th scope="col">House Rent</th>
          <th scope="col">Medical Allowance</th>
          <th scope="col">Tax Deduction</th>
          <th scope="col">PF Deduction</th>
          <th scope="col">Gross Salary</th>
          <th scope="col">Net Salary</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        {employee_salary.map((EmployeeSalary, i) => (
          <tr >
            {/* <th scope="row">{++i}</th> */}
            {/* <td>{EmployeeSalary.id}</td> */}
            <td>{EmployeeSalary.emp_id}</td>
            <td>{EmployeeSalary.basic_salary}</td>
            <td>{EmployeeSalary.hra}</td>
            <td>{EmployeeSalary.medical_allowance}</td>
            <td>{EmployeeSalary.tax_deduction}</td>
            <td>{EmployeeSalary.pf_deduction}</td>
            <td>{EmployeeSalary.gross_salary}</td>
            <td>{EmployeeSalary.net_salary}</td>
            <td>

              
                  {/* Edit button with icon */}
                  <Link to={`/EmployeeSalary/edit/${EmployeeSalary.id}`} className="btn btn-info me-2" 
                  style={{ width: "50px", display: "flex", justifyContent: "center" }}>
                  <i className="bi bi-pencil-square"></i>
                  </Link>
                  {/* Delete button with icon */}
                 <button
                  onClick={() => deleteemployee_salary(EmployeeSalary.id)}
                  className="btn btn-danger"
                  style={{ width: "50px", display: "flex", justifyContent: "center" }}>
                  <i className="bi bi-trash"></i>
                 </button>


            </td>
          </tr>
        ))}
      </tbody>
    </table>

 {/* Pagination  */}


<div className="pagination">

  <a
    className={currentPage === 1 ? "disabled" : ""}
    onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
  >
    « Previous
  </a>

  {[...Array(totalPages)].map((_, index) => (
    <a
      key={index}
      className={currentPage === index + 1 ? "active" : ""}
      onClick={() => setCurrentPage(index + 1)}
    >
      {index + 1}
    </a>
  ))}

  <a
    className={currentPage === totalPages ? "disabled" : ""}
    onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
  >
    Next »
  </a>

</div>


    </div>
  </div>
  {/* <Footer /> */}
</>


  );
};

export default EmpSalList;
