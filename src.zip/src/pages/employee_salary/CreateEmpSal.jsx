import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateEmpSal = () => {
  const navigate = useNavigate();

  // State for form data
  const [employee_salary, setEmployeeSalary] = useState({
    // id: '',
    emp_id: '',
    basic_salary: '',
    hra: '',
    medical_allowance: '',
    tax_deduction: '',
    pf_deduction: '',
    gross_salary: '',
    net_salary: ''
  });

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setEmployeeSalary((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/EmployeeSalary/save',
      method: 'POST',
      data: employee_salary
    })
      .then((res) => {
        if (res) navigate('/EmployeeSalary');
      })
      .catch((err) => console.log(err));
  };

  // Handle back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
      style={{
        maxWidth: '100%',
        margin: '50px auto',
        padding: '40px 50px',
        border: '1px solid #ccc',
        borderRadius: '10px',
        backgroundColor: '#fff',
        boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        fontSize: '15px',
        color: '#333',
      }}
    >
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-4"
        style={{
          cursor: 'pointer',
          padding: '8px 15px',
          fontSize: '14px',
          borderRadius: '6px',
          boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
        }}
      >
        &larr; Back
      </button>

      <h1 className="text-center mb-5" style={{ fontWeight: '600', color: '#222', letterSpacing: '0.04em' }}>
        <b>Create Employee Salary</b>
      </h1>

      <form onSubmit={handleSubmit}>

        {/* ID
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>ID</label>
          <input
            type="text"
            name="id"
            value={employee_salary.id}
            onChange={handleChange}
            placeholder="Enter ID"
            required
            style={{ width: '700px', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div> */}

        {/* Employee ID */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Employee ID</label>
          <input
            type="text"
            name="emp_id"
            value={employee_salary.emp_id}
            onChange={handleChange}
            placeholder="Enter Employee ID"
            required
            style={{ width: '700px', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Basic Salary */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Basic Salary</label>
          <input
            type="number"
            name="basic_salary"
            value={employee_salary.basic_salary}
            onChange={handleChange}
            placeholder="Enter Basic Salary"
            required
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* HRA */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>HRA</label>
          <input
            type="number"
            name="hra"
            value={employee_salary.hra}
            onChange={handleChange}
            placeholder="Enter HRA"
            required
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Medical Allowance */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Medical Allowance</label>
          <input
            type="number"
            name="medical_allowance"
            value={employee_salary.medical_allowance}
            onChange={handleChange}
            placeholder="Enter Medical Allowance"
            required
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Tax Deduction */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Tax Deduction</label>
          <input
            type="number"
            name="tax_deduction"
            value={employee_salary.tax_deduction}
            onChange={handleChange}
            placeholder="Enter Tax Deduction"
            required
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* PF Deduction */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>PF Deduction</label>
          <input
            type="number"
            name="pf_deduction"
            value={employee_salary.pf_deduction}
            onChange={handleChange}
            placeholder="Enter PF Deduction"
            required
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Gross Salary */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Gross Salary</label>
          <input
            type="number"
            name="gross_salary"
            value={employee_salary.gross_salary}
            onChange={handleChange}
            placeholder="Enter Gross Salary"
            required
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Net Salary */}
        <div style={{ marginBottom: '30px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Net Salary</label>
          <input
            type="number"
            name="net_salary"
            value={employee_salary.net_salary}
            onChange={handleChange}
            placeholder="Enter Net Salary"
            required
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Submit Button */}
        <div style={{ textAlign: 'center' }}>
          <button
            type="submit"
            className="btn btn-primary"
            style={{
              fontSize: '15px',
              fontWeight: '600',
              padding: '12px 36px',
              borderRadius: '8px',
              boxShadow: '0 3px 14px rgba(74, 144, 226, 0.5)',
              cursor: 'pointer',
              transition: 'background-color 0.3s, box-shadow 0.3s',
            }}
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateEmpSal;
