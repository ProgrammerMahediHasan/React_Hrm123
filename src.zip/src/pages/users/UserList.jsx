import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import "./pagination.css"
// import Header from '../../Layout/Header';
// import Footer from '../../Layout/Footer';

const UserList = () => {

  const getUsers = () => {
    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/user/",
      method: "GET",
      data: {}
    })
      .then((res) => {
        console.log(res.data.users);
        setUsers(res.data.users);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const [users, setUsers] = useState([]);

  useEffect(() => { getUsers(); }, []);

  // Delete function 
  const deleteUser = (id) => {
    const Delete = window.confirm("Are you sure you want to delete this user?");
    if (!Delete) return;

    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/user/delete/",
      method: "DELETE",
      data: { id }
    })
      .then(res => {
        console.log(res.data);
        getUsers(); // refresh table after delete
      })
      .catch(err => console.log(err));
  };


 // ✅ Pagination States
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 6;


  // ✅ Pagination Logic
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = users.slice(indexOfFirstRow, indexOfLastRow);

  const totalPages = Math.ceil(users.length / rowsPerPage);

  return (
    <>
      {/* <Header /> */}
      <h1 className="text-center my-4">User Management</h1>

      <div className="container" style={{ paddingBottom: "80px" }}>
        {/* Create Button */}
        <div className="d-flex justify-content-between align-items-center mb-3">
          <Link to="/user/create" className="btn btn-success">
            Add User
          </Link>
        </div>

        <table className="table table-bordered table-striped">
          <thead className="text-white"
                style={{ backgroundColor: "#0c3f7aea", fontSize: "0.88rem" }}>
            <tr>
              <th scope="col">SLNO</th>
              <th scope="col">USERNAME</th>
              <th scope="col">PASSWORD</th>
              <th scope="col">EMAIL</th>
              <th scope="col">ADDRESS</th>
              <th scope="col">STATUS</th>
              <th scope="col">ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, i) => (
              <tr key={i}>
                <th scope="row">{++i}</th>
                {/* <td>{user.id}</td> */}
                <td>{user.username}</td>
                <td>{user.password}</td>
                <td>{user.email}</td>
                <td>{user.address}</td>
                <td>{user.status}</td>
                <td>
                  
                 <div style={{ display: "flex", gap: "5px" }}>
  {/* Edit button with icon */}
  <Link 
    to={`/user/edit/${user.id}`} 
    className="btn btn-info" 
    style={{ 
      width: "50px", 
      height: "40px", 
      display: "flex", 
      justifyContent: "center", 
      alignItems: "center", 
      padding: "0" 
    }}
  >
    <i className="bi bi-pencil-square"></i>
  </Link>

  {/* Delete button with icon */}
  <button
    onClick={() => deleteUser(user.id)}
    className="btn btn-danger"
    style={{ 
      width: "50px", 
      height: "40px", 
      display: "flex", 
      justifyContent: "center", 
      alignItems: "center", 
      padding: "0" 
    }}
  >
    <i className="bi bi-trash"></i>
  </button>
</div>





                </td>
              </tr>
            ))}
          </tbody>
        </table>

 {/* Pagination  */}


<div className="pagination">

  <a
    className={currentPage === 1 ? "disabled" : ""}
    onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
  >
    « Previous
  </a>

  {[...Array(totalPages)].map((_, index) => (
    <a
      key={index}
      className={currentPage === index + 1 ? "active" : ""}
      onClick={() => setCurrentPage(index + 1)}
    >
      {index + 1}
    </a>
  ))}

  <a
    className={currentPage === totalPages ? "disabled" : ""}
    onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
  >
    Next »
  </a>

</div>



      </div>

      {/* <Footer /> */}
    </>
  );
};

export default UserList;
