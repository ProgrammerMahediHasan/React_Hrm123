import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditUser = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { userId } = useParams();

  const [user, setUser] = useState({
    id: '',
    username: '',
    password: '',
    email: '',
    address: '',
    status: '',
  });

  const navigate = useNavigate();

  // Fetch user data
  function fetchUser() {
   axios({
  url: `${baseUrl}/user/find/${userId}`,
  method: "GET",
  data: {}
})
.then((res) => {
  console.log(res.data.user);
  setUser({
    id: res.data.user.id,
    username: res.data.user.username,
    password: res.data.user.password,
    email: res.data.user.email,
    address: res.data.user.address,
    status: res.data.user.status
  });
})

      .catch((err) => { console.log(err) });
  }

  useEffect(() => {
    fetchUser();
  }, []);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUser(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  function handleSubmit(e) {
    e.preventDefault();

    axios({
      url: `${baseUrl}/user/update`,
      method: "PUT",
      data:  user 
    })
      .then((res) => {
        console.log(res.data);
        navigate("/user");
      })
      .catch((err) => { console.log(err) });
  }

  // Back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
       <div
  style={{
    maxWidth: '100%',
    margin: '50px auto',
    padding: '40px 50px',
    border: '1px solid #ccc',
    borderRadius: '10px',
    backgroundColor: '#fff',
    boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
    fontSize: '15px',
    color: '#333',
  }}
>
  {/* Back Button */}
  <button
    onClick={handleBack}
    className="btn btn-secondary mb-4"
  >
    ← Back
  </button>

  <h3 className="text-center mb-5">
    <b>Edit User</b>
  </h3>

  <form onSubmit={handleSubmit}>

    {/* Username */}
    <div style={{ marginBottom: '22px' }}>
      <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
        Username
      </label>
      <input
        value={user.username}
        name="username"
        type="text"
        onChange={handleChange}
        className="form-control"
        style={{
          width: '700px',
          padding: '11px 14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
        }}
      />
    </div>

    {/* Password */}
    <div style={{ marginBottom: '22px' }}>
      <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
        Password
      </label>
      <input
        value={user.password}
        name="password"
        type="text"
        onChange={handleChange}
        className="form-control"
        style={{
          width: '100%',
          padding: '11px 14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
        }}
      />
    </div>

    {/* Email */}
    <div style={{ marginBottom: '22px' }}>
      <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
        Email
      </label>
      <input
        value={user.email}
        name="email"
        type="text"
        onChange={handleChange}
        className="form-control"
        style={{
          width: '100%',
          padding: '11px 14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
        }}
      />
    </div>

    {/* Address */}
    <div style={{ marginBottom: '22px' }}>
      <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
        Address
      </label>
      <input
        value={user.address}
        name="address"
        type="text"
        onChange={handleChange}
        className="form-control"
        style={{
          width: '100%',
          padding: '11px 14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
        }}
      />
    </div>

    {/* Status */}
    <div style={{ marginBottom: '30px' }}>
      <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
        Status
      </label>
      <select
        name="status"
        value={user.status}
        onChange={handleChange}
        className="form-control"
        style={{
          width: '100%',
          padding: '11px 14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
        }}
      >
        <option value="">Select status</option>
        <option value="active">Active</option>
        <option value="inactive">Inactive</option>
      </select>
    </div>

    {/* Submit */}
    <div style={{ textAlign: 'center' }}>
      <button type="submit" className="btn btn-success px-5">
        Update
      </button>
    </div>

  </form>
</div>

  );
};

export default EditUser;
