import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditDailyAttendance = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { dailyattId } = useParams();

  const [daily_attendance, setAttendance] = useState({
    emp_id: '',
    att_date: '',
    day_type: '',
    in_time: '',
    out_time: '',
    total_work_minutes: '',
    status: '',
    late_minutes: '',
    overtime_minutes: '',
    remarks: ''
  });

  const navigate = useNavigate();

  // Fetch attendance data
  const fetchAttendance = () => {
    axios({
      url: `${baseUrl}/daily_attendance/find/${dailyattId}`,
      method: 'GET',
      data: {}
    })
    .then(res => {
      console.log(res.data.daily_attendance);
      setAttendance(res.data.daily_attendance); // API অনুযায়ী field names ঠিক করতে হবে
    })
    .catch(err => console.log('Fetch Error:', err));
  };

  useEffect(() => {
    fetchAttendance();
  }, []);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setAttendance(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  const handleSubmit = (e) => {
    e.preventDefault();

    axios({
      url: `${baseUrl}/daily_attendance/update`,
      method: 'PUT',
      data: daily_attendance
    })
    .then(res => {
      console.log('Updated:', res.data);
      navigate('/daily_attendance');
    })
    .catch(err => console.log('Update Error:', err));
  };

  const handleBack = () => navigate(-1);

  return (
    <div style={{ maxWidth: '700px', margin: '30px auto', padding: '20px', border: '1px solid #ccc', borderRadius: '8px' }}>
      <button onClick={handleBack} className="btn btn-secondary mb-3">&larr; Back</button>
      <h3 className="text-center mb-4">Edit Daily Attendance</h3>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label>Employee ID</label>
          <input type="text" name="emp_id" value={daily_attendance.emp_id} onChange={handleChange} className="form-control" required />
        </div>

        <div className="mb-3">
          <label>Attendance Date</label>
          <input type="date" name="att_date" value={daily_attendance.att_date} onChange={handleChange} className="form-control" required />
        </div>

        <div className="mb-3">
          <label>Day Type</label>
          <select name="day_type" value={daily_attendance.day_type} onChange={handleChange} className="form-control" required>
            <option value="">Select Day Type</option>
            <option value="working">Working Day</option>
            <option value="weekend">Weekend</option>
            <option value="holiday">Holiday</option>
          </select>
        </div>

        <div className="mb-3">
          <label>In Time</label>
          <input type="time" name="in_time" value={daily_attendance.in_time} onChange={handleChange} className="form-control" />
        </div>

        <div className="mb-3">
          <label>Out Time</label>
          <input type="time" name="out_time" value={daily_attendance.out_time} onChange={handleChange} className="form-control" />
        </div>

        <div className="mb-3">
          <label>Total Work Minutes</label>
          <input type="number" name="total_work_minutes" value={daily_attendance.total_work_minutes} onChange={handleChange} className="form-control" />
        </div>

        <div className="mb-3">
          <label>Status</label>
          <select name="status" value={attedaily_attendancendance.status} onChange={handleChange} className="form-control">
            <option value="">Select Status</option>
            <option value="present">Present</option>
            <option value="absent">Absent</option>
            <option value="leave">Leave</option>
          </select>
        </div>

        <div className="mb-3">
          <label>Late Minutes</label>
          <input type="number" name="late_minutes" value={daily_attendance.late_minutes} onChange={handleChange} className="form-control" />
        </div>

        <div className="mb-3">
          <label>Overtime Minutes</label>
          <input type="number" name="overtime_minutes" value={daily_attendance.overtime_minutes} onChange={handleChange} className="form-control" />
        </div>

        <div className="mb-3">
          <label>Remarks</label>
          <textarea name="remarks" value={daily_attendance.remarks} onChange={handleChange} className="form-control" rows="3"></textarea>
        </div>

        <div className="text-center">
          <button type="submit" className="btn btn-success">Update Attendance</button>
        </div>
      </form>
    </div>
  );
};

export default EditDailyAttendance;
