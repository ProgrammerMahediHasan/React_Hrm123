import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateDailyAttendance = () => {
  const [daily_attendance, setDailyAttendance] = useState({
    emp_id: '',
    att_date: '',
    day_type: '',
    in_time: '',
    out_time: '',
    total_work_minutes: '',
    status: '',
    late_minutes: '',
    overtime_minutes: '',
    remarks: ''
  });

  const navigate = useNavigate();

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setDailyAttendance((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/DailyAttendance/save/',
      method: 'POST',
      data: daily_attendance
    })
    .then((res) => {
      if (res) navigate('/DailyAttendance');
    })
    .catch((err) => console.log(err));
  };

  // Back button
  const handleBack = () => navigate(-1);

  const inputStyle = {
    width: '100%',
    padding: '11px 14px',
    fontSize: '14px',
    borderRadius: '6px',
    border: '1.3px solid #bbb',
    transition: 'border-color 0.3s',
  };

  const selectStyle = { ...inputStyle, appearance: 'none', backgroundColor: '#fff' };

  return (
    <div
      style={{
        maxWidth: '700px',
        margin: '50px auto',
        padding: '40px 50px',
        border: '1px solid #ccc',
        borderRadius: '10px',
        backgroundColor: '#fff',
        boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        fontSize: '15px',
        color: '#333',
      }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-4"
        style={{
          cursor: 'pointer',
          padding: '8px 15px',
          fontSize: '14px',
          borderRadius: '6px',
          boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
        }}
      >
        &larr; Back
      </button>

      <h2 className="text-center mb-5" style={{ fontWeight: '600', color: '#222' }}>
        Create Daily Attendance
      </h2>

      <form onSubmit={handleSubmit}>
        {/* Employee ID */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', display: 'block', marginBottom: '6px' }}>
            Employee ID
          </label>
          <input
            type="text"
            name="emp_id"
            value={daily_attendance.emp_id}
            onChange={handleChange}
            placeholder="Enter employee ID"
            required
            style={inputStyle}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          />
        </div>

        {/* Attendance Date */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', display: 'block', marginBottom: '6px' }}>
            Attendance Date
          </label>
          <input
            type="date"
            name="att_date"
            value={daily_attendance.att_date}
            onChange={handleChange}
            required
            style={inputStyle}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          />
        </div>

        {/* Day Type */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', display: 'block', marginBottom: '6px' }}>Day Type</label>
          <select
            name="day_type"
            value={daily_attendance.day_type}
            onChange={handleChange}
            required
            style={selectStyle}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          >
            <option value="">Select Day Type</option>
            <option value="working">Working Day</option>
            <option value="weekend">Weekend</option>
            <option value="holiday">Holiday</option>
          </select>
        </div>

        {/* In Time */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', display: 'block', marginBottom: '6px' }}>In Time</label>
          <input
            type="time"
            name="in_time"
            value={daily_attendance.in_time}
            onChange={handleChange}
            style={inputStyle}
          />
        </div>

        {/* Out Time */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', display: 'block', marginBottom: '6px' }}>Out Time</label>
          <input
            type="time"
            name="out_time"
            value={daily_attendance.out_time}
            onChange={handleChange}
            style={inputStyle}
          />
        </div>

        {/* Total Work Minutes */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', display: 'block', marginBottom: '6px' }}>
            Total Work Minutes
          </label>
          <input
            type="number"
            name="total_work_minutes"
            value={daily_attendance.total_work_minutes}
            onChange={handleChange}
            placeholder="Enter total work minutes"
            style={inputStyle}
          />
        </div>

        {/* Status */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', display: 'block', marginBottom: '6px' }}>Status</label>
          <select
            name="status"
            value={daily_attendance.status}
            onChange={handleChange}
            required
            style={selectStyle}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          >
            <option value="">Select Status</option>
            <option value="present">Present</option>
            <option value="absent">Absent</option>
            <option value="leave">Leave</option>
          </select>
        </div>

        {/* Late Minutes */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', display: 'block', marginBottom: '6px' }}>Late Minutes</label>
          <input
            type="number"
            name="late_minutes"
            value={daily_attendance.late_minutes}
            onChange={handleChange}
            placeholder="Enter late minutes"
            style={inputStyle}
          />
        </div>

        {/* Overtime Minutes */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', display: 'block', marginBottom: '6px' }}>Overtime Minutes</label>
          <input
            type="number"
            name="overtime_minutes"
            value={daily_attendance.overtime_minutes}
            onChange={handleChange}
            placeholder="Enter overtime minutes"
            style={inputStyle}
          />
        </div>

        {/* Remarks */}
        <div style={{ marginBottom: '30px' }}>
          <label style={{ fontWeight: '600', display: 'block', marginBottom: '6px' }}>Remarks</label>
          <textarea
            name="remarks"
            value={daily_attendance.remarks}
            onChange={handleChange}
            rows="3"
            placeholder="Write remarks..."
            style={inputStyle}
          ></textarea>
        </div>

        {/* Submit Button */}
        <div style={{ textAlign: 'center' }}>
          <button
            type="submit"
            className="btn btn-primary"
            style={{
              fontSize: '15px',
              fontWeight: '600',
              padding: '12px 36px',
              borderRadius: '8px',
              boxShadow: '0 3px 14px rgba(74, 144, 226, 0.5)',
              cursor: 'pointer',
              transition: 'background-color 0.3s, box-shadow 0.3s',
            }}
            onMouseEnter={(e) => {
              e.target.style.backgroundColor = '#3a78d8';
              e.target.style.boxShadow = '0 6px 22px rgba(58, 120, 216, 0.8)';
            }}
            onMouseLeave={(e) => {
              e.target.style.backgroundColor = '';
              e.target.style.boxShadow = '0 3px 14px rgba(74, 144, 226, 0.5)';
            }}
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateDailyAttendance;
