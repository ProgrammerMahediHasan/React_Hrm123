import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const EndDailyAttendance = () => {
  const navigate = useNavigate();
  const today = new Date().toISOString().split("T")[0];

  const [attDate, setAttDate] = useState(today);
  const [employees, setEmployees] = useState([]);
  const [attendance, setAttendance] = useState({});
  const [allChecked, setAllChecked] = useState(false);

  const holidays = [
    "2025-02-15","2025-02-21","2025-03-26","2025-03-28","2025-03-29","2025-03-30","2025-03-31",
    "2025-04-01","2025-04-02","2025-04-03","2025-04-14","2025-05-01","2025-05-11",
    "2025-06-05","2025-06-06","2025-06-07","2025-06-08","2025-06-09","2025-06-10",
    "2025-07-06","2025-08-05","2025-08-16","2025-09-05","2025-10-01","2025-10-02",
    "2025-12-16","2025-12-25"
  ];

  const calculateWorkTime = (inTime, outTime) => {
    if (!inTime || !outTime) return { minutes: 0, text: "0 hr 0 min", overtime: 0 };
    const [inH, inM] = inTime.split(":").map(Number);
    const [outH, outM] = outTime.split(":").map(Number);
    const inDate = new Date(2000, 0, 1, inH, inM);
    const outDate = new Date(2000, 0, 1, outH, outM);
    if (outDate < inDate) return { minutes: 0, text: "0 hr 0 min", overtime: 0 };
    const diffMin = Math.floor((outDate - inDate) / 60000);
    const regularEnd = new Date(2000, 0, 1, 17, 30);
    const overtime = outDate > regularEnd
      ? Math.floor((outDate - regularEnd) / 60000)
      : 0;
    return {
      minutes: diffMin,
      text: `${Math.floor(diffMin / 60)} hr ${diffMin % 60} min`,
      overtime
    };
  };

  const getDayType = (dateStr) => {
    const date = new Date(dateStr);
    const day = date.getDay(); // Friday = 5
    if (holidays.includes(dateStr)) return "Holiday";
    if (day === 5) return "Weekend";
    return "Working";
  };

  useEffect(() => {
    axios.get("http://localhost:8080/PHP_Converted/admin/api/Employee/")
      .then(res => {
        const empList = res.data.employees || [];
        setEmployees(empList);

        const init = {};
        empList.forEach(emp => {
          init[emp.id] = {
            in_checked: false,
            out_checked: false,
            in_time: "09:00",
            out_time: "17:30",
            work_time: "0 hr 0 min",
            work_minutes: 0,
            overtime_minutes: 0,
            late_minutes: 0,
            day_type: getDayType(today),
            status: null
          };
        });
        setAttendance(init);
      })
      .catch(console.log);
  }, []);

  const handleChange = (empId, field, value) => {
    setAttendance(prev => {
      const updated = { ...prev[empId], [field]: value };
      const dayType = getDayType(attDate);
      updated.day_type = dayType;

      if (
        (dayType === "Weekend" || dayType === "Holiday") &&
        (updated.in_checked || updated.out_checked)
      ) {
        updated.status = "Day Off";
        updated.in_time = null;
        updated.out_time = null;
        updated.work_time = "0 hr 0 min";
        updated.work_minutes = 0;
        updated.overtime_minutes = 0;
        updated.late_minutes = 0;
        return { ...prev, [empId]: updated };
      }

      const inTime = updated.in_checked ? updated.in_time : null;
      const outTime = updated.out_checked ? updated.out_time : null;
      const work = calculateWorkTime(inTime, outTime);

      updated.work_time = work.text;
      updated.work_minutes = work.minutes;
      updated.overtime_minutes = work.overtime;

      let late = 0;
      let status = null;

      if (updated.in_checked && updated.in_time) {
        const [h, m] = updated.in_time.split(":").map(Number);
        const inMin = h * 60 + m;
        if (inMin <= 540) status = "Present";
        else if (inMin <= 600) {
          late = inMin - 540;
          status = "Present";
        } else {
          status = "Absent";
        }
      }

      updated.late_minutes = late;
      updated.status = status;

      return { ...prev, [empId]: updated };
    });
  };

  const handleAllCheck = (value) => {
    setAllChecked(value);
    employees.forEach(emp => {
      handleChange(emp.id, "in_checked", value);
      handleChange(emp.id, "out_checked", value);
    });
  };

  // ✅ NEW: Clear attendance (ONLY ADDITION)
  const handleClearAttendance = () => {
    const reset = {};
    employees.forEach(emp => {
      reset[emp.id] = {
        in_checked: false,
        out_checked: false,
        in_time: "09:00",
        out_time: "17:30",
        work_time: "0 hr 0 min",
        work_minutes: 0,
        overtime_minutes: 0,
        late_minutes: 0,
        day_type: getDayType(attDate),
        status: null
      };
    });

    setAttendance(reset);
    setAllChecked(false);
  };

  const handleSaveAttendance = async () => {
    const selected = employees.filter(
      emp => attendance[emp.id]?.in_checked || attendance[emp.id]?.out_checked
    );

    if (!selected.length) {
      alert("❌ Select at least one employee");
      return;
    }

    await Promise.all(
      selected.map(emp => {
        const att = attendance[emp.id];
        return axios.post(
          "http://localhost:8080/PHP_Converted/admin/api/DailyAttendance/save/",
          {
            emp_id: emp.id,
            att_date: attDate,
            status: att.status,
            in_time: att.in_checked ? att.in_time : null,
            out_time: att.out_checked ? att.out_time : null,
            total_work_minutes: att.work_minutes,
            overtime_minutes: att.overtime_minutes,
            late_minutes: att.late_minutes,
            day_type: att.day_type
          }
        );
      })
    );

    alert("✅ Attendance Saved Successfully!");
  };

  return (
    <div className="container mt-4">
      
      <button onClick={() => navigate(-1)} className="btn btn-secondary mb-3">
        Back
      </button>

      <h3 className="text-center mb-4">Daily Attendance</h3>

      {/* ✅ Date + Clear */}
      <div className="text-center mb-4 d-flex justify-content-center gap-3">
        <input
          type="date"
          value={attDate}
          onChange={e => setAttDate(e.target.value)}
          className="form-control w-25"
        />

        <button
  type="button"
  onClick={handleClearAttendance}
  className="btn btn-danger clear-btn"
>
  Clear
</button>

      </div>

      <table className="table table-bordered text-center">
        <thead className="text-white"
        style={{ backgroundColor: "#0c3f7aea", fontSize: "0.88rem" }}
        >
          <tr>
            <th>SL</th>
            <th>Name</th>
            <th>
              IN All <br />
              <input
                type="checkbox"
                checked={allChecked}
                onChange={e => handleAllCheck(e.target.checked)}
              />
            </th>
            <th>IN Time</th>
            <th>
              OUT All <br />
              <input
                type="checkbox"
                checked={allChecked}
                onChange={e => handleAllCheck(e.target.checked)}
              />
            </th>
            <th>OUT Time</th>
            <th>Work(Min)</th>
            <th>Late(Min)</th>
            <th>Over Time</th>
            <th>Day Type</th>
            <th>Status</th>
          </tr>
        </thead>

        <tbody>
          {employees.map((emp, i) => (
            <tr key={emp.id}>
              <td>{i + 1}</td>
              <td>{emp.name}</td>

              <td>
                <input
                  type="checkbox"
                  checked={attendance[emp.id]?.in_checked || false}
                  onChange={e =>
                    handleChange(emp.id, "in_checked", e.target.checked)
                  }
                />
              </td>

              <td>
                <input
                  type="time"
                  value={attendance[emp.id]?.in_time || ""}
                  onChange={e =>
                    handleChange(emp.id, "in_time", e.target.value)
                  }
                  className="form-control form-control-sm"
                />
              </td>

              <td>
                <input
                  type="checkbox"
                  checked={attendance[emp.id]?.out_checked || false}
                  onChange={e =>
                    handleChange(emp.id, "out_checked", e.target.checked)
                  }
                />
              </td>

              <td>
                <input
                  type="time"
                  value={attendance[emp.id]?.out_time || ""}
                  onChange={e =>
                    handleChange(emp.id, "out_time", e.target.value)
                  }
                  className="form-control form-control-sm"
                />
              </td>

              <td>{attendance[emp.id]?.work_time}</td>
              <td>{attendance[emp.id]?.late_minutes}</td>
              <td>{attendance[emp.id]?.overtime_minutes}</td>

              <td
                style={{
                  color:
                    attendance[emp.id]?.day_type === "Weekend"
                      ? "red"
                      : attendance[emp.id]?.day_type === "Holiday"
                      ? "green"
                      : "inherit",
                  fontWeight:
                    attendance[emp.id]?.day_type === "Weekend" ||
                    attendance[emp.id]?.day_type === "Holiday"
                      ? "bold"
                      : "normal"
                }}
              >
                {attendance[emp.id]?.day_type}
              </td>

              <td
                style={{
                  color:
                    attendance[emp.id]?.status === "Absent"
                      ? "red"
                      : "inherit",
                  fontWeight:
                    attendance[emp.id]?.status === "Absent"
                      ? "bold"
                      : "normal"
                }}
              >
                {attendance[emp.id]?.status}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="text-center">
        <button
          onClick={handleSaveAttendance}
          className="btn btn-success px-5"
        >
          ✅ Save Attendance
        </button>
      </div>
    </div>
  );
};

export default EndDailyAttendance;
