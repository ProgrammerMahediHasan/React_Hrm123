import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const EndDailyAttendance = () => {
  const navigate = useNavigate();
  const today = new Date().toISOString().split("T")[0];

  const [attDate, setAttDate] = useState(today);
  const [employees, setEmployees] = useState([]);
  const [attendance, setAttendance] = useState({}); // { empId: { in_checked, out_checked, in_time, out_time } }

  // Fetch employees
  useEffect(() => {
    axios
      .get("http://localhost:8080/PHP_Converted/admin/api/Employee/")
      .then((res) => {
        const empList = res.data.employees || [];
        setEmployees(empList);

        const initAttendance = {};
        empList.forEach((emp) => {
          initAttendance[emp.id] = {
            in_checked: false,
            out_checked: false,
            in_time: "09:00",
            out_time: "17:30",
          };
        });
        setAttendance(initAttendance);
      })
      .catch(console.log);
  }, []);

  // Checkbox / time change
  const handleChange = (empId, field, value) => {
    setAttendance((prev) => ({
      ...prev,
      [empId]: { ...prev[empId], [field]: value },
    }));
  };

  // Toggle all checkboxes
  const toggleAll = (field, value) => {
    const newAttendance = { ...attendance };
    employees.forEach((emp) => {
      newAttendance[emp.id] = {
        ...newAttendance[emp.id],
        [field]: value,
      };
    });
    setAttendance(newAttendance);
  };

  // Save attendance
  const handleSaveAttendance = async () => {
    try {
      // Only save employees with at least one checkbox checked
      const selectedEmployees = employees.filter(
        (emp) =>
          attendance[emp.id]?.in_checked || attendance[emp.id]?.out_checked
      );

      if (selectedEmployees.length === 0) {
        alert("❌ Please select at least one employee to save!");
        return;
      }

      const requests = selectedEmployees.map((emp) => {
        const att = attendance[emp.id];
        return axios.post(
          "http://localhost:8080/PHP_Converted/admin/api/DailyAttendance/save/",
          {
            emp_id: emp.id,
            att_date: attDate,
            status: att.in_checked ? "Present" : "Absent",
            in_time: att.in_checked ? att.in_time : null,
            out_time: att.out_checked ? att.out_time : null,
          }
        );
      });

      await Promise.all(requests);
      alert("✅ Attendance Saved Successfully!");
    } catch (error) {
      console.log(error);
      alert("❌ Failed to save attendance");
    }
  };

  return (
    <div className="container mt-4">
      <button onClick={() => navigate(-1)} className="btn btn-secondary mb-3">
        Back
      </button>

      <h3 className="text-center mb-4">Daily Attendance (IN/OUT)</h3>

      {/* Attendance Date */}
      <div className="mb-3 text-center">
        <label className="fw-bold me-2">Attendance Date</label>
        <input
          type="date"
          value={attDate}
          onChange={(e) => setAttDate(e.target.value)}
          className="form-control d-inline w-25 text-center"
        />
      </div>

      <table className="table table-bordered text-center">
        <thead className="table-primary">
          <tr>
            <th>SL</th>
            <th>Employee Name</th>
            <th>
              IN <br />
              <input
                type="checkbox"
                checked={
                  employees.length > 0 &&
                  employees.every((emp) => attendance[emp.id]?.in_checked)
                }
                onChange={(e) => toggleAll("in_checked", e.target.checked)}
              />
            </th>
            <th>IN Time</th>
            <th>
              OUT <br />
              <input
                type="checkbox"
                checked={
                  employees.length > 0 &&
                  employees.every((emp) => attendance[emp.id]?.out_checked)
                }
                onChange={(e) => toggleAll("out_checked", e.target.checked)}
              />
            </th>
            <th>OUT Time</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp, i) => (
            <tr key={emp.id}>
              <td>{i + 1}</td>
              <td>{emp.name}</td>

              {/* IN Checkbox */}
              <td>
                <input
                  type="checkbox"
                  checked={attendance[emp.id]?.in_checked || false}
                  onChange={(e) =>
                    handleChange(emp.id, "in_checked", e.target.checked)
                  }
                />
              </td>

              {/* IN Time */}
              <td>
                <input
                  type="time"
                  value={attendance[emp.id]?.in_time || "09:00"}
                  onChange={(e) =>
                    handleChange(emp.id, "in_time", e.target.value)
                  }
                  className="form-control form-control-sm"
                  style={{ width: "100px", margin: "auto" }}
                />
              </td>

              {/* OUT Checkbox */}
              <td>
                <input
                  type="checkbox"
                  checked={attendance[emp.id]?.out_checked || false}
                  onChange={(e) =>
                    handleChange(emp.id, "out_checked", e.target.checked)
                  }
                />
              </td>

              {/* OUT Time */}
              <td>
                <input
                  type="time"
                  value={attendance[emp.id]?.out_time || "17:30"}
                  onChange={(e) =>
                    handleChange(emp.id, "out_time", e.target.value)
                  }
                  className="form-control form-control-sm"
                  style={{ width: "100px", margin: "auto" }}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="text-center mt-3">
        <button onClick={handleSaveAttendance} className="btn btn-success px-5">
          ✅ Save Attendance
        </button>
      </div>
    </div>
  );
};

export default EndDailyAttendance;
