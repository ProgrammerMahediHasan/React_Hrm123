import axios from "axios";
import React, { useEffect, useState } from "react";
import "./pagination.css";

const DailyAttendReport = () => {
  const [daily_attendance, setDailyAttenReport] = useState([]);
  const [empId, setEmpId] = useState(""); // Employee ID filter
  const [reportDate, setReportDate] = useState(""); // Date filter

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 6;
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = (daily_attendance || []).slice(indexOfFirstRow, indexOfLastRow);
  const totalPages = Math.ceil((daily_attendance || []).length / rowsPerPage);

  // Fetch Daily Attendance based on Employee ID or Date
  const getDailyAttenReport = () => {
    axios
      .post(
        "http://localhost:8080/PHP_Converted/admin/api/DailyAttendance/dailyAttReport/",
        { id: empId || null, report_date: reportDate || null }
      )
      .then((res) => {
        setDailyAttenReport(res.data.daily_attendance || []);
        setCurrentPage(1); // Reset to first page
      })
      .catch((err) => console.log(err));
  };

  // Clear filters
  const clearFilters = () => {
    setEmpId("");
    setReportDate("");
    setDailyAttenReport([]);
    setCurrentPage(1);
  };

  // Call API whenever filters change
  // useEffect(() => {
  //   getDailyAttenReport();
  // }, [empId, reportDate]);

  return (
    <>
      <h1 className="text-center my-4">Employee Daily Attendance Report</h1>

      {/* Filters */}
      <div className="container mb-3">
        <div className="row g-2">
          <div className="col-md-3">
            <input
              type="text"
              className="form-control"
              placeholder="Enter Employee ID"
              value={empId}
              onChange={(e) => setEmpId(e.target.value)}
            />
          </div>
          <div className="col-md-3">
            <input
              type="date"
              className="form-control"
              value={reportDate}
              onChange={(e) => setReportDate(e.target.value)}
            />
          </div>
          <div className="col-md-3 d-flex gap-2">
            <button className="btn btn-primary w-50" onClick={getDailyAttenReport}>
              Search
            </button>
            <button className="btn btn-secondary w-50" onClick={clearFilters}>
              Clear
            </button>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="container">
        <table className="table table-bordered table-striped">
          <thead
            className="text-white"
            style={{ backgroundColor: "#0c3f7a", fontSize: "0.88rem" }}
          >
            <tr>
              <th>Emp ID</th>
              <th>Emp Name</th>
              <th>Atten Date</th>
              <th>In Time</th>
              <th>Out Time</th>
              <th>Total Work Time</th>
              <th>Status</th>
              <th>Late Time</th>
              <th>Over Time</th>
            </tr>
          </thead>
          <tbody>
            {currentRows.map((dailyAttenReport, i) => (
              <tr key={i}>
                <td>{dailyAttenReport.emp_id}</td>
                <td>{dailyAttenReport.emp_name}</td>
                <td>{dailyAttenReport.att_date}</td>
                <td>{dailyAttenReport.in_time}</td>
                <td>{dailyAttenReport.out_time}</td>
                <td>{dailyAttenReport.total_work_minutes}</td>
                <td>{dailyAttenReport.status}</td>
                <td>{dailyAttenReport.late_minutes}</td>
                <td>{dailyAttenReport.overtime_minutes}</td>
              </tr>
            ))}
            {currentRows.length === 0 && (
              <tr>
                <td colSpan="9" className="text-center text-muted py-3">
                  No records found
                </td>
              </tr>
            )}
          </tbody>
        </table>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="pagination">
            <a
              className={currentPage === 1 ? "disabled" : ""}
              onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
            >
              « Previous
            </a>

            {[...Array(totalPages)].map((_, index) => (
              <a
                key={index}
                className={currentPage === index + 1 ? "active" : ""}
                onClick={() => setCurrentPage(index + 1)}
              >
                {index + 1}
              </a>
            ))}

            <a
              className={currentPage === totalPages ? "disabled" : ""}
              onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
            >
              Next »
            </a>
          </div>
        )}
      </div>
    </>
  );
};

export default DailyAttendReport;
