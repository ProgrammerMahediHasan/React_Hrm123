import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const EndDailyAttendance = () => {
  const navigate = useNavigate();
  const today = new Date().toISOString().split("T")[0];

  const [attDate, setAttDate] = useState(today);
  const [employees, setEmployees] = useState([]);
  const [attendance, setAttendance] = useState({}); // { empId: { in_checked, out_checked, in_time, out_time } }

  // ================= Fetch Employees =================
  useEffect(() => {
    axios
      .get("http://localhost:8080/PHP_Converted/admin/api/Employee/")
      .then((res) => {
        const empList = res.data.employees || [];
        setEmployees(empList);

        const initAttendance = {};
        empList.forEach((emp) => {
          initAttendance[emp.id] = {
            in_checked: false,
            out_checked: false,
            in_time: "09:00",
            out_time: "17:30",
          };
        });
        setAttendance(initAttendance);
      })
      .catch((err) => console.log(err));
  }, []);

  // ================= Handle Checkbox =================
  const handleCheckboxChange = (empId, field, checked) => {
    setAttendance((prev) => ({
      ...prev,
      [empId]: { ...prev[empId], [field]: checked },
    }));
  };

  // ================= Handle Time =================
  const handleTimeChange = (empId, field, time) => {
    setAttendance((prev) => ({
      ...prev,
      [empId]: { ...prev[empId], [field]: time },
    }));
  };

  // ================= SAVE ATTENDANCE =================
  const handleSaveAttendance = async () => {
    try {
      for (const emp of employees) {
        const att = attendance[emp.id];

        await axios.post(
          "http://localhost:8080/PHP_Converted/admin/api/DailyAttendance/save/",
          {
            emp_id: emp.id,
            att_date: attDate,
            status: att.in_checked ? "Present" : "Absent",
            in_time: att.in_checked ? att.in_time : null,
            out_time: att.out_checked ? att.out_time : null,
          }
        );
      }
      alert("✅ Attendance Saved Successfully!");
    } catch (error) {
      console.log(error);
      alert("❌ Failed to save attendance");
    }
  };

  return (
    <div className="container mt-4">
      <button onClick={() => navigate(-1)} className="btn btn-secondary mb-3">
        Back
      </button>

      <h3 className="text-center mb-4">Daily Attendance (IN/OUT)</h3>

      {/* Attendance Date */}
      <div className="mb-3 text-center">
        <label className="fw-bold me-2">Attendance Date</label>
        <input
          type="date"
          value={attDate}
          onChange={(e) => setAttDate(e.target.value)}
          className="form-control d-inline w-25 text-center"
        />
      </div>

      {/* Attendance Table */}
      <table className="table table-bordered text-center">
        <thead className="table-primary">
          <tr>
            <th>SL</th>
            <th>Employee Name</th>
            <th>IN</th>
            <th>IN Time</th>
            <th>OUT</th>
            <th>OUT Time</th>
          </tr>
        </thead>
        <tbody>
          {employees.map((emp, i) => (
            <tr key={emp.id}>
              <td>{i + 1}</td>
              <td>{emp.name}</td>

              {/* IN Checkbox */}
              <td>
                <input
                  type="checkbox"
                  checked={attendance[emp.id]?.in_checked || false}
                  onChange={(e) =>
                    handleCheckboxChange(emp.id, "in_checked", e.target.checked)
                  }
                />
              </td>

              {/* IN Time */}
              <td>
                <input
                  type="time"
                  value={attendance[emp.id]?.in_time || "09:00"}
                  onChange={(e) =>
                    handleTimeChange(emp.id, "in_time", e.target.value)
                  }
                  className="form-control form-control-sm"
                  style={{ width: "100px", margin: "auto" }}
                />
              </td>

              {/* OUT Checkbox */}
              <td>
                <input
                  type="checkbox"
                  checked={attendance[emp.id]?.out_checked || false}
                  onChange={(e) =>
                    handleCheckboxChange(emp.id, "out_checked", e.target.checked)
                  }
                />
              </td>

              {/* OUT Time */}
              <td>
                <input
                  type="time"
                  value={attendance[emp.id]?.out_time || "17:30"}
                  onChange={(e) =>
                    handleTimeChange(emp.id, "out_time", e.target.value)
                  }
                  className="form-control form-control-sm"
                  style={{ width: "100px", margin: "auto" }}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <div className="text-center mt-3">
        <button onClick={handleSaveAttendance} className="btn btn-success px-5">
          ✅ Save Attendance
        </button>
      </div>
    </div>
  );
};

export default EndDailyAttendance;
