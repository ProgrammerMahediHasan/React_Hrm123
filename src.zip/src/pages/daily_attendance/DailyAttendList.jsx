import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import "./pagination.css";

const DailyAttendList = () => {
  const [daily_attendance, setDailyAttendance] = useState([]);

  const getDailyAttendance = () => {
    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/DailyAttendance/",
      method: "GET",
      data: {}
    })
      .then((res) => {
        setDailyAttendance(res.data.daily_attendance);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    getDailyAttendance();
  }, []);

  const deletedaily_attendance = (id) => {
    const Delete = window.confirm("Are you sure you want to delete this DailyAttendance?");
    if (!Delete) return;

    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/DailyAttendance/delete/",
      method: "DELETE",
      data: { id }
    })
      .then(() => {
        getDailyAttendance();
      })
      .catch(err => console.log(err));
  };

  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 6;
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = daily_attendance.slice(indexOfFirstRow, indexOfLastRow);
  const totalPages = Math.ceil(daily_attendance.length / rowsPerPage);

  return (
    <>
      <h1 className="text-center my-4">Employee Daily Attendance</h1>

      <div className="container" style={{ paddingBottom: "80px" }}>
        <div className="d-flex justify-content-between align-items-center mb-4">
          <Link to="/DailyAttendance/create" className="btn btn-success">
            Add Attendance
          </Link>
        </div>

        <div className="container">
          <table className="table table-bordered table-striped">
            <thead className="text-white"
               style={{ backgroundColor: "#0c3f7aea", fontSize: "0.88rem" }}>
              <tr>
                <th>Emp ID</th>
                <th>Attend Date</th>
                <th>Day Type</th>
                <th>In Time</th>
                <th>Out Time</th>
                <th>Work Time</th>
                <th>Status</th>
                <th>Late Time</th>
                <th>Over Time</th>
                <th>Remarks</th>
                <th>Actions</th>
              </tr>
            </thead>

            <tbody>
              {currentRows.map((DailyAttendance, i) => (
                <tr key={i}>
                  <td>{DailyAttendance.emp_id}</td>
                  <td>{DailyAttendance.att_date}</td>
                  <td
                    style={{
                      color: DailyAttendance.day_type === "Weekend" ? "red" :
                             DailyAttendance.day_type === "Holiday" ? "green" : "inherit",
                      fontWeight: DailyAttendance.day_type === "Weekend" || DailyAttendance.day_type === "Holiday" ? "bold" : "normal"
                    }}
                  >
                    {DailyAttendance.day_type}
                  </td>
                  <td>{DailyAttendance.in_time}</td>
                  <td>{DailyAttendance.out_time}</td>
                  <td>{DailyAttendance.total_work_minutes}</td>
                  <td style={{
                    color: DailyAttendance.status === "Absent" ? "red" : "inherit",
                    fontWeight: DailyAttendance.status === "Absent" ? "bold" : "normal"
                  }}>
                    <b>{DailyAttendance.status}</b>
                  </td>
                  <td>{DailyAttendance.late_minutes}</td>
                  <td>{DailyAttendance.overtime_minutes}</td>
                  <td>{DailyAttendance.remarks}</td>
                  <td>
                    <Link to={`/DailyAttendance/edit/${DailyAttendance.id}`} className="btn btn-info me-2" 
                      style={{ width: "50px", display: "flex", justifyContent: "center" }}>
                      <i className="bi bi-pencil-square"></i>
                    </Link>
                    <button
                      onClick={() => deletedaily_attendance(DailyAttendance.id)}
                      className="btn btn-danger"
                      style={{ width: "50px", display: "flex", justifyContent: "center" }}>
                      <i className="bi bi-trash"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="pagination">
            <a
              className={currentPage === 1 ? "disabled" : ""}
              onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
            >
              « Previous
            </a>

            {[...Array(totalPages)].map((_, index) => (
              <a
                key={index}
                className={currentPage === index + 1 ? "active" : ""}
                onClick={() => setCurrentPage(index + 1)}
              >
                {index + 1}
              </a>
            ))}

            <a
              className={currentPage === totalPages ? "disabled" : ""}
              onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
            >
              Next »
            </a>
          </div>
        </div>
      </div>
    </>
  );
};

export default DailyAttendList;
