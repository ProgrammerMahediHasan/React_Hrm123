import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateEmp = () => {
  const [employee, setEmployee] = useState({
    name: '',
    dept_id: '',
    desig_id: '',
    gender: '',
    email: '',
    phone: '',
    status: '',
    joining_date: ''
  });

  // Fetch department
  const [department, setDepartment] = useState([]);
  function fetchDepartment() {
    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/department/',
      method: 'GET',
      data: {}
    })
      .then((res) => {
        setDepartment(res.data.department);
      })
      .catch((err) => console.log(err));
  }
  useEffect(() => {
    fetchDepartment();
  }, []);

  // Fetch designation
  const [designation, setDesignation] = useState([]);
  function fetchDesignation() {
    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/designation/',
      method: 'GET',
      data: {}
    })
      .then((res) => {
        setDesignation(res.data.designations);
      })
      .catch((err) => console.log(err));
  }
  useEffect(() => {
    fetchDesignation();
  }, []);

  const navigate = useNavigate();

  // Handle change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setEmployee((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Submit
  const handleSubmit = (e) => {
    e.preventDefault();
    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/employee/save',
      method: 'POST',
      data: employee
    })
      .then((res) => {
        if (res) navigate('/employee');
      })
      .catch((err) => console.log(err));
  };

  // Back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
      style={{
        maxWidth: '70%',
        margin: '50px auto',
        padding: '40px 50px',
        border: '1px solid #ccc',
        borderRadius: '10px',
        backgroundColor: '#fff',
        boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        fontSize: '15px',
        color: '#333',
      }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-4"
        style={{
          cursor: 'pointer',
          padding: '8px 15px',
          fontSize: '14px',
          borderRadius: '6px',
          boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
        }}
      >
        &larr; Back
      </button>

      <h2
        className="text-center mb-5"
        style={{ fontWeight: '600', color: '#222', letterSpacing: '0.04em' }}
      >
        Create Employee
      </h2>

      <form onSubmit={handleSubmit}>

        {/* Name */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="name" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Name
          </label>
          <input
            type="text"
            id="name"
            name="name"
            value={employee.name}
            onChange={handleChange}
            placeholder="Enter name"
            required
           style={{
              width: '700px',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
              transition: 'border-color 0.3s',
            }}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          />
        </div>

        {/* Department */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="dept_id" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Department
          </label>
          <select
            id="dept_id"
            name="dept_id"
            value={employee.dept_id}
            onChange={handleChange}
            required
            style={{
              width: '100%',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
              transition: 'border-color 0.3s',
              appearance: 'none',
              backgroundColor: '#fff',
            }}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          >
            <option value="">Select Department</option>
            {department.map((d, i) => (
              <option key={i} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>
        </div>

        {/* Designation */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="desig_id" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Designation
          </label>
          <select
            id="desig_id"
            name="desig_id"
            value={employee.desig_id}
            onChange={handleChange}
            required
            style={{
              width: '100%',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
              transition: 'border-color 0.3s',
              appearance: 'none',
              backgroundColor: '#fff',
            }}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          >
            <option value="">Select Designation</option>
            {designation.map((dg, i) => (
              <option key={i} value={dg.id}>
                {dg.name}
              </option>
            ))}
          </select>
        </div>

        {/* Gender */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="gender" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Gender
          </label>
          <select
            id="gender"
            name="gender"
            value={employee.gender}
            onChange={handleChange}
            required
            style={{
              width: '100%',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
              transition: 'border-color 0.3s',
              appearance: 'none',
              backgroundColor: '#fff',
            }}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          >
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
        </div>

        {/* Email */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="email" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Email
          </label>
          <input
            type="email"
            id="email"
            name="email"
            value={employee.email}
            onChange={handleChange}
            placeholder="Enter email"
            required
            style={{
              width: '100%',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
              transition: 'border-color 0.3s',
            }}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          />
        </div>

        {/* Phone */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="phone" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Phone
          </label>
          <input
            type="text"
            id="phone"
            name="phone"
            value={employee.phone}
            onChange={handleChange}
            placeholder="Enter phone number"
            required
            style={{
              width: '100%',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
              transition: 'border-color 0.3s',
            }}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          />
        </div>

        {/* Status */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="status" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Status
          </label>
          <select
            id="status"
            name="status"
            value={employee.status}
            onChange={handleChange}
            required
            style={{
              width: '100%',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
              transition: 'border-color 0.3s',
              appearance: 'none',
              backgroundColor: '#fff',
            }}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          >
            <option value="">Select Status</option>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </select>
        </div>

        {/* Joining Date */}
        <div style={{ marginBottom: '30px' }}>
          <label htmlFor="joining_date" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Joining Date
          </label>
          <input
            type="date"
            id="joining_date"
            name="joining_date"
            value={employee.joining_date}
            onChange={handleChange}
            required
            style={{
              width: '100%',
              padding: '11px 14px',
              fontSize: '14px',
              borderRadius: '6px',
              border: '1.3px solid #bbb',
              transition: 'border-color 0.3s',
            }}
            onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
            onBlur={(e) => (e.target.style.borderColor = '#bbb')}
          />
        </div>

        {/* Submit Button */}
        <div style={{ textAlign: 'center' }}>
          <button
            type="submit"
            className="btn btn-primary"
            style={{
              fontSize: '15px',
              fontWeight: '600',
              padding: '12px 36px',
              borderRadius: '8px',
              boxShadow: '0 3px 14px rgba(74, 144, 226, 0.5)',
              cursor: 'pointer',
              transition: 'background-color 0.3s, box-shadow 0.3s',
            }}
            onMouseEnter={(e) => {
              e.target.style.backgroundColor = '#3a78d8';
              e.target.style.boxShadow = '0 6px 22px rgba(58, 120, 216, 0.8)';
            }}
            onMouseLeave={(e) => {
              e.target.style.backgroundColor = '';
              e.target.style.boxShadow = '0 3px 14px rgba(74, 144, 226, 0.5)';
            }}
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateEmp;
