import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditEmp = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { empId } = useParams();

  const [employee, setEmployee] = useState({
    id: '',
    name: '',
    dept_id: '',
    desig_id: '',
    gender: '',
    email: '',
    phone: '',
    status: '',
    joining_date: ''
  });

  const navigate = useNavigate();

  // Fetch employee data
  function fetchemployee() {
   axios({
  url: `${baseUrl}/employee/find/${empId}`,
  method: "GET",
  data: {}
})
.then((res) => {
  console.log(res.data.employee);
  setEmployee({
    id: res.data.employee.id,
    name: res.data.employee.name,
    dept_id: res.data.employee.dept_id,
    desig_id: res.data.employee.desig_id,
    gender: res.data.employee.gender,
    email: res.data.employee.email,
    phone: res.data.employee.phone,
    status: res.data.employee.status,
    joining_date: res.data.employee.joining_date
  });
})

      .catch((err) => { console.log(err) });
  }

  useEffect(() => {
    fetchemployee();
  }, []);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setEmployee(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  function handleSubmit(e) {
    e.preventDefault();

    axios({
      url: `${baseUrl}/employee/update`,
      method: "PUT",
      data:  employee 
    })
      .then((res) => {
        console.log(res.data);
        navigate("/employee");
      })
      .catch((err) => { console.log(err) });
  }

  // Back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
  <div
  style={{
    maxWidth: '70%',
    margin: '50px auto',
    padding: '40px 50px',
    border: '1px solid #ccc',
    borderRadius: '10px',
    backgroundColor: '#fff',
    boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
    fontSize: '15px',
    color: '#333',
  }}
>
  {/* Back Button */}
  <button
    onClick={handleBack}
    className="btn btn-secondary mb-4"
    style={{
      cursor: 'pointer',
      padding: '8px 15px',
      fontSize: '14px',
      borderRadius: '6px',
      boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
    }}
  >
    &larr; Back
  </button>

  <h3
    className="text-center mb-5"
    style={{ fontWeight: '600', color: '#222', letterSpacing: '0.04em' }}
  >
    Edit Employee Information
  </h3>

  <form onSubmit={handleSubmit}>
    {/* Name */}
    <div style={{ marginBottom: '22px' }}>
      <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
        Name
      </label>
      <input
        type="text"
        name="employeename"
        value={employee.name}
        onChange={handleChange}
        placeholder="Enter name"
        required
        style={{
          width: '700px',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          transition: 'border-color 0.3s',
        }}
        onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
        onBlur={(e) => (e.target.style.borderColor = '#bbb')}
      />
    </div>

    {/* Department */}
    <div style={{ marginBottom: '22px' }}>
      <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Department</label>
      <input
        type="text"
        name="dept_id"
        value={employee.dept_id}
        onChange={handleChange}
        placeholder="Enter department"
        required
        style={{
          width: '100%',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          transition: 'border-color 0.3s',
        }}
        onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
        onBlur={(e) => (e.target.style.borderColor = '#bbb')}
      />
    </div>

    {/* Designation */}
    <div style={{ marginBottom: '22px' }}>
      <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Designation</label>
      <input
        type="text"
        name="desig_id"
        value={employee.desig_id}
        onChange={handleChange}
        placeholder="Enter designation"
        required
        style={{
          width: '100%',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          transition: 'border-color 0.3s',
        }}
        onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
        onBlur={(e) => (e.target.style.borderColor = '#bbb')}
      />
    </div>

    {/* Email */}
    <div style={{ marginBottom: '22px' }}>
      <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Email</label>
      <input
        type="email"
        name="email"
        value={employee.email}
        onChange={handleChange}
        placeholder="Enter email"
        required
        style={{
          width: '100%',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          transition: 'border-color 0.3s',
        }}
        onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
        onBlur={(e) => (e.target.style.borderColor = '#bbb')}
      />
    </div>

    {/* Phone */}
    <div style={{ marginBottom: '22px' }}>
      <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Phone</label>
      <input
        type="text"
        name="phone"
        value={employee.phone}
        onChange={handleChange}
        placeholder="Enter phone number"
        required
        style={{
          width: '100%',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          transition: 'border-color 0.3s',
        }}
        onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
        onBlur={(e) => (e.target.style.borderColor = '#bbb')}
      />
    </div>

    {/* Status */}
    <div style={{ marginBottom: '22px' }}>
      <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Status</label>
      <select
        name="status"
        value={employee.status}
        onChange={handleChange}
        required
        style={{
          width: '100%',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          transition: 'border-color 0.3s',
          appearance: 'none',
          backgroundColor: '#fff',
        }}
        onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
        onBlur={(e) => (e.target.style.borderColor = '#bbb')}
      >
        <option value="">Select Status</option>
        <option value="active">Active</option>
        <option value="inactive">Inactive</option>
      </select>
    </div>

    {/* Gender */}
    <div style={{ marginBottom: '22px' }}>
      <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Gender</label>
      <select
        name="gender"
        value={employee.gender}
        onChange={handleChange}
        required
        style={{
          width: '100%',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          transition: 'border-color 0.3s',
          appearance: 'none',
          backgroundColor: '#fff',
        }}
        onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
        onBlur={(e) => (e.target.style.borderColor = '#bbb')}
      >
        <option value="">Select Gender</option>
        <option value="male">Male</option>
        <option value="female">Female</option>
      </select>
    </div>

    {/* Joining Date */}
    <div style={{ marginBottom: '30px' }}>
      <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Joining Date</label>
      <input
        type="date"
        name="joining_date"
        value={employee.joining_date}
        onChange={handleChange}
        required
        style={{
          width: '100%',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          transition: 'border-color 0.3s',
        }}
        onFocus={(e) => (e.target.style.borderColor = '#4a90e2')}
        onBlur={(e) => (e.target.style.borderColor = '#bbb')}
      />
    </div>

    {/* Submit Button */}
    <div style={{ textAlign: 'center' }}>
      <button
        type="submit"
        className="btn btn-success"
        style={{
          fontSize: '15px',
          fontWeight: '600',
          padding: '12px 36px',
          borderRadius: '8px',
          boxShadow: '0 3px 14px rgba(74, 144, 226, 0.5)',
          cursor: 'pointer',
          transition: 'background-color 0.3s, box-shadow 0.3s',
        }}
        onMouseEnter={(e) => {
          e.target.style.backgroundColor = '#3a78d8';
          e.target.style.boxShadow = '0 6px 22px rgba(58, 120, 216, 0.8)';
        }}
        onMouseLeave={(e) => {
          e.target.style.backgroundColor = '';
          e.target.style.boxShadow = '0 3px 14px rgba(74, 144, 226, 0.5)';
        }}
      >
        Update
      </button>
    </div>
  </form>
</div>


  );
};

export default EditEmp;
