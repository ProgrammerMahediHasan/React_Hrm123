import axios from "axios";
import React, { useEffect, useState } from "react";
import "./pagination.css";

const EmployInfo = () => {
  const [employees, setEmployees] = useState([]);
  const [search, setSearch] = useState("");
  const [showData, setShowData] = useState(false);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 6;

  // Fetch Employees
  useEffect(() => {
    axios
      .get("http://localhost:8080/PHP_Converted/admin/api/employee/")
      .then((res) => setEmployees(res.data.employees || []))
      .catch((error) => console.log(error));
  }, []);

  // Reset page when search / showData changes
  useEffect(() => setCurrentPage(1), [search, showData]);

  // Filter logic
  const filteredEmployees = employees.filter((emp) => {
    if (!showData) return false;
    return emp.name?.toLowerCase().includes(search.toLowerCase());
  });

  // Pagination logic
  const totalPages = Math.max(1, Math.ceil(filteredEmployees.length / rowsPerPage));
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = filteredEmployees.slice(indexOfFirstRow, indexOfLastRow);

  // ✅ Clear button function
  const clearSearch = () => {
    setSearch("");
    setShowData(false);
    setCurrentPage(1);
  };

  return (
    <div className="container-fluid px-2">
      <div className="card border-0 shadow-lg rounded-4 overflow-hidden">
        {/* Header */}
        <div className="card-header bg-gradient bg-primary py-2 text-center">
          <h1 className="mb-0 text-white">
            <i className="bi bi-people-fill"></i> Employees Information Report
          </h1>
        </div>
        <br />

        <div className="card-body bg-light p-2">
          {/* Search Section */}
          <div className="row mb-3 g-2">
            <div className="col-md-4">
              <input
                type="text"
                className="form-control"
                placeholder="Search by name"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setShowData(e.target.value.trim() !== "");
                }}
              />
            </div>

            <div className="col-md-2 d-flex gap-2">
              <button className="btn btn-primary w-50" onClick={() => setShowData(true)}>
                Search
              </button>
              <button className="btn btn-secondary w-50" onClick={clearSearch}>
                Clear
              </button>
            </div>

            <div className="col-md-3">
              <select
                className="form-select"
                onChange={(e) => {
                  if (e.target.value === "all") {
                    setShowData(true);
                    setSearch("");
                  } else {
                    setShowData(false);
                  }
                }}
              >
                <option value="">Choose</option>
                <option value="all">All Employees</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="table-responsive">
            <table
              className="table table-bordered align-middle text-center table-striped table-hover mb-0"
              style={{ fontSize: "0.85rem" }}
            >
              <thead className="text-white" style={{ backgroundColor: "#0c3f7aea" }}>
                <tr>
                  <th>ID</th>
                  <th style={{ minWidth: "200px" }}>Name</th>
                  <th>Department</th>
                  <th>Designation</th>
                  <th>Gender</th>
                  <th style={{ minWidth: "220px" }}>Email</th>
                  <th>Phone</th>
                  <th>Status</th>
                  <th style={{ minWidth: "130px" }}>Joining Date</th>
                </tr>
              </thead>
              <tbody>
                {!showData ? (
                  <tr>
                    <td colSpan="10" className="text-center text-muted py-3">
                      Please search "name" or select "All Employees"
                    </td>
                  </tr>
                ) : currentRows.length > 0 ? (
                  currentRows.map((row) => {
                    const badgeClass = row.status?.toLowerCase() === "active" ? "bg-success" : "bg-danger";
                    return (
                      <tr key={row.id}>
                        <td>{row.id}</td>
                        <td>{row.name}</td>
                        <td>{row.department || "N/A"}</td>
                        <td>{row.designation || "N/A"}</td>
                        <td>{row.gender}</td>
                        <td>{row.email}</td>
                        <td>{row.phone}</td>
                        <td>
                          <span className={`badge ${badgeClass}`}>{row.status}</span>
                        </td>
                        <td>
                          {new Date(row.joining_date).toLocaleDateString("en-GB", {
                            day: "2-digit",
                            month: "short",
                            year: "numeric",
                          })}
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan="10" className="text-center text-danger py-3">
                      No employee found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>

            <br />

            {/* Pagination */}
            {showData && filteredEmployees.length > 0 && (
              <div className="pagination">
                <a
                  className={currentPage === 1 ? "disabled" : ""}
                  onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
                >
                  « Previous
                </a>

                {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                  <a key={page} className={currentPage === page ? "active" : ""} onClick={() => setCurrentPage(page)}>
                    {page}
                  </a>
                ))}

                <a
                  className={currentPage === totalPages ? "disabled" : ""}
                  onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
                >
                  Next »
                </a>
              </div>
            )}
            <br />
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployInfo;
