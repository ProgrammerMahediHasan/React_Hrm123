import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import "./pagination.css";
const LeaveReqList = () => {

  const [leave_request, setLeaveRequest] = useState([]);


  const getLeaveRequest = () => {
    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/LeaveRequest/",
      method: "GET",
      data: {}
    })
      .then((res) => {
        setLeaveRequest(res.data.leave_request);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  useEffect(() => {
    getLeaveRequest();
  }, []);

  // ✅ Delete function
  const deleteleave_request = (id) => {
    const Delete = window.confirm("Are you sure you want to delete this Leave Request?");
    if (!Delete) return;

    axios({
      url: "http://localhost:8080/PHP_Converted/admin/api/LeaveRequest/delete/",
      method: "DELETE",
      data: { id }
    })
      .then(() => {
        getLeaveRequest();
      })
      .catch(err => console.log(err));
  };

  // ✅ Pagination States
  const [currentPage, setCurrentPage] = useState(1);
  const rowsPerPage = 6;


  // ✅ Pagination Logic
  const indexOfLastRow = currentPage * rowsPerPage;
  const indexOfFirstRow = indexOfLastRow - rowsPerPage;
  const currentRows = leave_request.slice(indexOfFirstRow, indexOfLastRow);

  const totalPages = Math.ceil(leave_request.length / rowsPerPage);

  return (
    <>
      <h1 className="text-center my-4">Employee Leave Request</h1>

      <div className="container" style={{ paddingBottom: "80px" }}>
        <div className="d-flex justify-content-between align-items-center mb-4">
          <Link to="/LeaveRequest/create" className="btn btn-success">
            Add Leave Request
          </Link>
        </div>

        <div className="container">
          <table className="table table-bordered table-striped">
            <thead className="text-white"
                style={{ backgroundColor: "#0c3f7aea", fontSize: "0.88rem" }}>
              <tr>
                <th>Employee</th>
                <th>Leave Type</th>
                <th>From</th>
                <th>To</th>
                <th>Total Days</th>
                <th>Reason</th>
                <th>Attachment</th>
                <th>Status</th>
                <th>Applied Time</th>
                <th>Approved By</th>
                <th>Approved Time</th>
                <th>Paid Leave</th>
                <th>Actions</th>
              </tr>
            </thead>

            <tbody>
              {currentRows.map((LeaveRequest, i) => (
                <tr key={i}>
                  <td>{LeaveRequest.emp_id}</td>
                  <td>{LeaveRequest.leave_type}</td>
                  <td>{LeaveRequest.from_date}</td>
                  <td>{LeaveRequest.to_date}</td>
                  <td>{LeaveRequest.total_days}</td>
                  <td>{LeaveRequest.reason}</td>
                  <td>{LeaveRequest.attachment}</td>
                  <td>{LeaveRequest.status}</td>
                  <td>{LeaveRequest.applied_time}</td>
                  <td>{LeaveRequest.approved_by}</td>
                  <td>{LeaveRequest.approved_time}</td>
                  <td>{LeaveRequest.paid_leave}</td>
                  <td>

              
              {/* Edit button with icon */}
                                <Link to={`/LeaveRequest/edit/${LeaveRequest.id}`} className="btn btn-info me-2" 
                                style={{ width: "50px", display: "flex", justifyContent: "center" }}>
                                  <i className="bi bi-pencil-square"></i>
                                </Link>
                               {/* Delete button with icon */}
                              <button
                                onClick={() => deleteleave_request(LeaveRequest.id)}
                                className="btn btn-danger"
                                style={{ width: "50px", display: "flex", justifyContent: "center" }}>
                                <i className="bi bi-trash"></i>
                              </button>



                  </td>
                </tr>
              ))}
            </tbody>
          </table>

{/* Pagination  */}


<div className="pagination">

  <a
    className={currentPage === 1 ? "disabled" : ""}
    onClick={() => currentPage > 1 && setCurrentPage(currentPage - 1)}
  >
    « Previous
  </a>

  {[...Array(totalPages)].map((_, index) => (
    <a
      key={index}
      className={currentPage === index + 1 ? "active" : ""}
      onClick={() => setCurrentPage(index + 1)}
    >
      {index + 1}
    </a>
  ))}

  <a
    className={currentPage === totalPages ? "disabled" : ""}
    onClick={() => currentPage < totalPages && setCurrentPage(currentPage + 1)}
  >
    Next »
  </a>

</div>

        

        </div>
      </div>
    </>
  );
};

export default LeaveReqList;
