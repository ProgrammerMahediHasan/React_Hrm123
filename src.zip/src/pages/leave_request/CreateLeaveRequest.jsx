import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateLeaveRequest = () => {
  const navigate = useNavigate();

  const [leave_request, setLeaveRequest] = useState({
    leave_id: '',
    emp_id: '',
    leave_type: '',
    start_date: '',
    end_date: '',
    reason: '',
    status: 'pending', // default status
    approver_id: '',
    applied_on: new Date().toISOString().split('T')[0], // today's date
  });

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setLeaveRequest((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/LeaveRequest/save',
      method: 'POST',
      data: leave_request
    })
      .then((res) => {
        if (res) navigate('/LeaveRequest');
      })
      .catch((err) => console.error(err));
  };

  // Handle back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
      style={{
        maxWidth: '100%',
        margin: '50px auto',
        padding: '40px 50px',
        border: '1px solid #ccc',
        borderRadius: '10px',
        backgroundColor: '#fff',
        boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        fontSize: '15px',
        color: '#333',
      }}
    >
      {/* Back Button */}
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-4"
        style={{
          cursor: 'pointer',
          padding: '8px 15px',
          fontSize: '14px',
          borderRadius: '6px',
          boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
        }}
      >
        &larr; Back
      </button>

      <h2
        className="text-center mb-5"
        style={{ fontWeight: '600', color: '#222', letterSpacing: '0.04em' }}
      >
        Create Leave Request
      </h2>

      <form onSubmit={handleSubmit}>

        {/* Leave ID */}
        {/* <div style={{ marginBottom: '22px' }}>
          <label htmlFor="leave_id" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Leave ID
          </label>
          <input
            type="text"
            id="leave_id"
            name="leave_id"
            value={leave_request.leave_id}
            onChange={handleChange}
            placeholder="Enter Leave ID"
            required
            style={{ width: '700px', padding: '11px 14px', fontSize: '14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div> */}

        {/* Employee ID */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="emp_id" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Employee ID
          </label>
          <input
            type="text"
            id="emp_id"
            name="emp_id"
            value={leave_request.emp_id}
            onChange={handleChange}
            placeholder="Enter Employee ID"
            required
            style={{ width: '700px', padding: '11px 14px', fontSize: '14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Leave Type */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="leave_type" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Leave Type
          </label>
          <input
            type="text"
            id="leave_type"
            name="leave_type"
            value={leave_request.leave_type}
            onChange={handleChange}
            placeholder="Enter Leave Type"
            required
            style={{ width: '700px', padding: '11px 14px', fontSize: '14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Start Date */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="start_date" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Start Date
          </label>
          <input
            type="date"
            id="start_date"
            name="start_date"
            value={leave_request.start_date}
            onChange={handleChange}
            required
            style={{ width: '700px', padding: '11px 14px', fontSize: '14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* End Date */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="end_date" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            End Date
          </label>
          <input
            type="date"
            id="end_date"
            name="end_date"
            value={leave_request.end_date}
            onChange={handleChange}
            required
            style={{ width: '700px', padding: '11px 14px', fontSize: '14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Reason */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="reason" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Reason
          </label>
          <textarea
            id="reason"
            name="reason"
            value={leave_request.reason}
            onChange={handleChange}
            placeholder="Enter reason for leave"
            required
            rows="4"
            style={{ width: '700px', padding: '11px 14px', fontSize: '14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Approver ID */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="approver_id" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Approver ID
          </label>
          <input
            type="text"
            id="approver_id"
            name="approver_id"
            value={leave_request.approver_id}
            onChange={handleChange}
            placeholder="Enter Approver ID"
            required
            style={{ width: '700px', padding: '11px 14px', fontSize: '14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Applied On */}
        <div style={{ marginBottom: '22px' }}>
          <label htmlFor="applied_on" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
            Applied On
          </label>
          <input
            type="date"
            id="applied_on"
            name="applied_on"
            value={leave_request.applied_on}
            onChange={handleChange}
            required
            style={{ width: '700px', padding: '11px 14px', fontSize: '14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Status */}
<div style={{ marginBottom: '22px' }}>
  <label htmlFor="status" style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>
    Status
  </label>
  <select
    id="status"
    name="status"
    value={leave_request.status}
    onChange={handleChange}
    required
    style={{
      width: '700px',
      padding: '11px 14px',
      fontSize: '14px',
      borderRadius: '6px',
      border: '1.3px solid #bbb',
    }}
  >
    <option value="pending">Pending</option>
    <option value="approved">Approved</option>
    <option value="rejected">Rejected</option>
  </select>
</div>


        {/* Submit Button */}
        <div style={{ textAlign: 'center' }}>
          <button
            type="submit"
            className="btn btn-primary"
            style={{ fontSize: '15px', fontWeight: '600', padding: '12px 36px', borderRadius: '8px', cursor: 'pointer' }}
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateLeaveRequest;
