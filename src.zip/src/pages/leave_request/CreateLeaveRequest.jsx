import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const CreateLeaveRequest = () => {
  const navigate = useNavigate();

  // State for form data
  const [leave_request, setLeaveRequest] = useState({
    emp_id: '',
    leave_type: '',
    from_date: '',
    to_date: '',
    total_days: '',
    reason: '',
    attachment: '',
    status: '',
    applied_time: '',
    approved_by: '',
    approved_time: '',
    paid_leave: ''
  });

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setLeaveRequest((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    axios({
      url: 'http://localhost:8080/PHP_Converted/admin/api/LeaveRequest/save',
      method: 'POST',
      data: leave_request
    })
      .then((res) => {
        if (res) navigate('/LeaveRequest');
      })
      .catch((err) => console.log(err));
  };

  // Handle back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
      style={{
        maxWidth: '100%',
        margin: '50px auto',
        padding: '40px 50px',
        border: '1px solid #ccc',
        borderRadius: '10px',
        backgroundColor: '#fff',
        boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
        fontSize: '15px',
        color: '#333',
      }}
    >
      <button
        onClick={handleBack}
        className="btn btn-secondary mb-4"
        style={{
          cursor: 'pointer',
          padding: '8px 15px',
          fontSize: '14px',
          borderRadius: '6px',
          boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
        }}
      >
        &larr; Back
      </button>

      <h1 className="text-center mb-5" style={{ fontWeight: '600', color: '#222', letterSpacing: '0.04em' }}>
        <b>Create Leave Request</b>
      </h1>

      <form onSubmit={handleSubmit}>

        {/* Employee ID */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Employee ID</label>
          <input
            type="text"
            name="emp_id"
            value={leave_request.emp_id}
            onChange={handleChange}
            placeholder="Enter Employee ID"
            required
            style={{ width: '700px', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Leave Type */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Leave Type</label>
          <input
            type="text"
            name="leave_type"
            value={leave_request.leave_type}
            onChange={handleChange}
            placeholder="Enter leave type"
            required
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* From Date */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>From Date</label>
          <input
            type="date"
            name="from_date"
            value={leave_request.from_date}
            onChange={handleChange}
            required
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* To Date */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>To Date</label>
          <input
            type="date"
            name="to_date"
            value={leave_request.to_date}
            onChange={handleChange}
            required
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Total Days */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Total Days</label>
          <input
            type="number"
            name="total_days"
            value={leave_request.total_days}
            onChange={handleChange}
            placeholder="Enter total days"
            required
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Reason */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Reason</label>
          <textarea
            name="reason"
            value={leave_request.reason}
            onChange={handleChange}
            placeholder="Enter reason"
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb', minHeight: '80px' }}
            required
          />
        </div>

        {/* Attachment */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Attachment</label>
          <input
            type="file"
            name="attachment"
            onChange={(e) => setLeaveRequest((prev) => ({ ...prev, attachment: e.target.files[0] }))}
            style={{ width: '100%', padding: '6px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Status */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Status</label>
          <select
            name="status"
            value={leave_request.status}
            onChange={handleChange}
            required
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          >
            <option value="">Select status</option>
            <option value="Pending">Pending</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>

        {/* Applied Time */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Applied Time</label>
          <input
            type="datetime-local"
            name="applied_time"
            value={leave_request.applied_time}
            onChange={handleChange}
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Approved By */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Approved By</label>
          <input
            type="text"
            name="approved_by"
            value={leave_request.approved_by}
            onChange={handleChange}
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Approved Time */}
        <div style={{ marginBottom: '22px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Approved Time</label>
          <input
            type="datetime-local"
            name="approved_time"
            value={leave_request.approved_time}
            onChange={handleChange}
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>


        {/* Approved Time */}
            <div style={{ marginBottom: '22px' }}>
            <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Approved Time</label>
            <input
                type="datetime-local"
                name="approved_time"
                value={leave_request.approved_time}
                onChange={handleChange}
                style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
            />
            </div>


        {/* Paid Leave */}
        <div style={{ marginBottom: '30px' }}>
          <label style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}>Paid Leave</label>
          <input
            type="number"
            name="paid_leave"
            value={leave_request.paid_leave}
            onChange={handleChange}
            style={{ width: '100%', padding: '11px 14px', borderRadius: '6px', border: '1.3px solid #bbb' }}
          />
        </div>

        {/* Submit Button */}
        <div style={{ textAlign: 'center' }}>
          <button
            type="submit"
            className="btn btn-primary"
            style={{
              fontSize: '15px',
              fontWeight: '600',
              padding: '12px 36px',
              borderRadius: '8px',
              boxShadow: '0 3px 14px rgba(74, 144, 226, 0.5)',
              cursor: 'pointer',
              transition: 'background-color 0.3s, box-shadow 0.3s',
            }}
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default CreateLeaveRequest;
