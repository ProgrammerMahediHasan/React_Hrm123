import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

const EditRole = () => {
  const baseUrl = import.meta.env.VITE_BASE_URL;
  const { roleId } = useParams();

  const [role, setRole] = useState({
    id: '',
    name: ''
  });

  const navigate = useNavigate();

  // Fetch role data
  function fetchRole() {
    axios({
      url: `${baseUrl}/role/find/${roleId}`,
      method: "GET",
      data: {}
    })
      .then((res) => {
        console.log(res.data.role);
        setRole({
          id: res.data.role.id,
          name: res.data.role.name
        });
      })
      .catch((err) => { console.log(err) });
  }

  useEffect(() => {
    fetchRole();
  }, []);

  // Handle input change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setRole(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Handle form submit
  function handleSubmit(e) {
    e.preventDefault();

    axios({
      url: `${baseUrl}/role/update`,
      method: "PUT",
      data: { role }
    })
      .then((res) => {
        console.log(res.data);
        navigate("/role");
      })
      .catch((err) => { console.log(err) });
  }

  // Back button
  const handleBack = () => {
    navigate(-1);
  };

  return (
    <div
  style={{
    maxWidth: '100%',
    margin: '50px auto',
    padding: '40px 50px',
    border: '1px solid #ccc',
    borderRadius: '10px',
    backgroundColor: '#fff',
    boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
    fontSize: '15px',
    color: '#333',
  }}
>
  {/* Back Button */}
  <button
    onClick={handleBack}
    className="btn btn-secondary mb-4"
    style={{
      cursor: 'pointer',
      padding: '8px 15px',
      fontSize: '14px',
      borderRadius: '6px',
      boxShadow: '0 1px 4px rgba(0,0,0,0.1)',
    }}
  >
    &larr; Back
  </button>

  <h2
    className="text-center mb-5"
    style={{ fontWeight: '600', color: '#222', letterSpacing: '0.04em' }}
  >
    Edit Role
  </h2>

  <form onSubmit={handleSubmit}>
    {/* Role Name */}
    <div style={{ marginBottom: '22px' }}>
      <label
        style={{ fontWeight: '600', marginBottom: '6px', display: 'block' }}
      >
        Role Name
      </label>
      <input
        type="text"
        name="name"
        value={role.name}
        onChange={handleChange}
        required
        style={{
          width: '500px',
          padding: '11px 14px',
          fontSize: '14px',
          borderRadius: '6px',
          border: '1.3px solid #bbb',
          transition: 'border-color 0.3s',
        }}
      />
    </div>

    {/* Submit Button */}
    <div style={{ textAlign: 'center' }}>
      <button
        type="submit"
        className="btn btn-success"
        style={{
          fontSize: '15px',
          fontWeight: '600',
          padding: '12px 36px',
          borderRadius: '8px',
        }}
      >
        Update
      </button>
    </div>
  </form>
</div>

  );
};

export default EditRole;
